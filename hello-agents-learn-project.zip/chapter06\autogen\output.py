import streamlit as st
import requests
import pandas as pd
import time
from datetime import datetime

# 页面配置
st.set_page_config(
    page_title="Bitcoin Price Tracker",
    page_icon="₿",
    layout="centered"
)

# 应用标题
st.title("₿ Bitcoin Price Tracker")
st.markdown("实时监控比特币价格走势")

# 配置常量
CACHE_DURATION = 5  # 缓存时间（秒）
API_TIMEOUT = 10    # API请求超时（秒）

# 初始化session state
if 'last_fetch' not in st.session_state:
    st.session_state.last_fetch = 0
if 'cached_data' not in st.session_state:
    st.session_state.cached_data = None
if 'last_error' not in st.session_state:
    st.session_state.last_error = None

def validate_api_response(data):
    """验证API响应数据的完整性和格式"""
    if not isinstance(data, dict):
        return False, "API返回数据格式异常"
    
    if 'bitcoin' not in data:
        return False, "API响应中缺少bitcoin数据"
    
    bitcoin_data = data['bitcoin']
    if not isinstance(bitcoin_data, dict):
        return False, "Bitcoin数据格式异常"
    
    # 检查必要字段
    required_fields = ['usd', 'usd_24h_change']
    missing_fields = []
    
    for field in required_fields:
        if field not in bitcoin_data:
            missing_fields.append(field)
    
    if missing_fields:
        return False, f"API数据缺少必要字段: {', '.join(missing_fields)}"
    
    # 验证数据类型
    if not isinstance(bitcoin_data['usd'], (int, float)):
        return False, "价格数据类型异常"
    
    if not isinstance(bitcoin_data['usd_24h_change'], (int, float)):
        return False, "涨跌幅数据类型异常"
    
    return True, "数据验证通过"

def fetch_bitcoin_data():
    """从CoinGecko API获取比特币数据"""
    try:
        # 检查缓存
        current_time = time.time()
        if (st.session_state.cached_data is not None and 
            current_time - st.session_state.last_fetch < CACHE_DURATION):
            return st.session_state.cached_data, None
        
        # API请求
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            'ids': 'bitcoin',
            'vs_currencies': 'usd',
            'include_24hr_change': 'true',
            'include_24hr_vol': 'true',
            'include_market_cap': 'true'
        }
        
        response = requests.get(url, params=params, timeout=API_TIMEOUT)
        response.raise_for_status()
        
        data = response.json()
        
        # 验证数据
        is_valid, validation_message = validate_api_response(data)
        if not is_valid:
            st.session_state.last_error = validation_message
            return None, validation_message
        
        # 提取并处理数据
        bitcoin_data = data['bitcoin']
        
        # 确保数据格式正确
        processed_data = {
            'price': float(bitcoin_data['usd']),
            'change_percent': float(bitcoin_data['usd_24h_change']),
            'volume_24h': bitcoin_data.get('usd_24h_vol', 0),
            'market_cap': bitcoin_data.get('usd_market_cap', 0),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # 计算变化金额
        processed_data['change_amount'] = processed_data['price'] * (processed_data['change_percent'] / 100)
        
        # 更新缓存
        st.session_state.cached_data = processed_data
        st.session_state.last_fetch = current_time
        st.session_state.last_error = None
        
        return processed_data, None
        
    except requests.exceptions.Timeout:
        error_msg = "API请求超时，请稍后重试"
        st.session_state.last_error = error_msg
        return None, error_msg
    except requests.exceptions.ConnectionError:
        error_msg = "网络连接失败，请检查网络连接"
        st.session_state.last_error = error_msg
        return None, error_msg
    except requests.exceptions.HTTPError as e:
        error_msg = f"API请求失败: HTTP {e.response.status_code}"
        st.session_state.last_error = error_msg
        return None, error_msg
    except requests.exceptions.RequestException as e:
        error_msg = f"网络请求异常: {str(e)}"
        st.session_state.last_error = error_msg
        return None, error_msg
    except ValueError as e:
        error_msg = f"数据解析错误: {str(e)}"
        st.session_state.last_error = error_msg
        return None, error_msg
    except Exception as e:
        error_msg = f"未知错误: {str(e)}"
        st.session_state.last_error = error_msg
        return None, error_msg

def format_price(price):
    """格式化价格显示"""
    if price is None:
        return "N/A"
    return f"${price:,.2f}"

def format_volume(volume):
    """格式化交易量显示"""
    if volume is None:
        return "N/A"
    
    if volume >= 1_000_000_000:
        return f"${volume/1_000_000_000:.2f}B"
    elif volume >= 1_000_000:
        return f"${volume/1_000_000:.2f}M"
    else:
        return f"${volume:,.0f}"

def display_error_message(error_message):
    """显示友好的错误信息"""
    st.error("⚠️ 数据获取失败")
    st.warning(error_message)
    st.info("请尝试：")
    st.markdown("""
    1. 检查网络连接
    2. 稍后重试
    3. 点击手动刷新按钮
    """)

def display_price_card(data):
    """显示价格卡片"""
    if data is None:
        return
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.metric(
            label="当前价格",
            value=format_price(data['price']),
            delta=f"{data['change_percent']:+.2f}%"
        )
    
    with col2:
        change_color = "green" if data['change_amount'] >= 0 else "red"
        change_icon = "📈" if data['change_amount'] >= 0 else "📉"
        st.markdown(
            f"<h3 style='color:{change_color};'>{change_icon} 24h变化</h3>"
            f"<p style='color:{change_color}; font-size:20px;'>"
            f"${data['change_amount']:+,.2f}</p>",
            unsafe_allow_html=True
        )

def display_market_info(data):
    """显示市场信息"""
    if data is None:
        return
    
    st.divider()
    st.subheader("📊 市场概览")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            label="24h交易量",
            value=format_volume(data['volume_24h'])
        )
    
    with col2:
        st.metric(
            label="市值",
            value=format_volume(data['market_cap'])
        )
    
    with col3:
        change_percent = data['change_percent']
        if change_percent > 5:
            trend = "📈 强劲上涨"
        elif change_percent > 1:
            trend = "↗️ 温和上涨"
        elif change_percent > -1:
            trend = "➡️ 横盘整理"
        elif change_percent > -5:
            trend = "↘️ 温和下跌"
        else:
            trend = "📉 大幅下跌"
        
        st.metric(
            label="市场趋势",
            value=trend
        )

def main():
    """主应用函数"""
    # 侧边栏控制
    with st.sidebar:
        st.header("⚙️ 设置")
        
        # 刷新控制
        auto_refresh = st.checkbox("自动刷新", value=True)
        refresh_interval = st.slider("刷新间隔(秒)", 5, 60, 10, 5)
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔄 刷新", use_container_width=True, type="primary"):
                st.session_state.cached_data = None
                st.rerun()
        
        with col2:
            if st.button("🗑️ 清除缓存", use_container_width=True):
                st.session_state.cached_data = None
                st.session_state.last_fetch = 0
                st.rerun()
        
        st.divider()
        
        # 状态信息
        st.header("📈 状态")
        if st.session_state.cached_data:
            st.success("✅ 数据已缓存")
            st.caption(f"最后更新: {st.session_state.cached_data['timestamp']}")
        else:
            st.info("🔄 等待数据...")
        
        if st.session_state.last_error:
            st.warning(f"⚠️ 上次错误: {st.session_state.last_error}")
        
        st.divider()
        
        # 帮助信息
        st.header("❓ 帮助")
        st.markdown("""
        - **自动刷新**: 启用后定时更新数据
        - **手动刷新**: 立即获取最新数据
        - **清除缓存**: 强制重新获取数据
        - **颜色说明**: 绿色=上涨，红色=下跌
        """)
    
    # 主内容区域
    # 显示加载状态
    with st.spinner("正在获取比特币价格数据..."):
        data, error = fetch_bitcoin_data()
    
    if error:
        display_error_message(error)
        
        # 显示重试选项
        if st.button("🔄 重试获取数据"):
            st.session_state.cached_data = None
            st.rerun()
        
        return
    
    if data is None:
        st.warning("无法获取数据，请稍后重试")
        return
    
    # 显示价格卡片
    display_price_card(data)
    
    # 显示市场信息
    display_market_info(data)
    
    # 显示详细信息
    st.divider()
    st.subheader("📋 详细信息")
    
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **价格**: {format_price(data['price'])}  
        **24小时涨跌**: {data['change_percent']:+.2f}%  
        **变化金额**: ${data['change_amount']:+,.2f}
        """)
    
    with info_col2:
        st.markdown(f"""
        **24小时交易量**: {format_volume(data['volume_24h'])}  
        **市值**: {format_volume(data['market_cap'])}  
        **最后更新**: {data['timestamp']}
        """)
    
    # 显示数据来源
    st.caption("数据来源: CoinGecko API • 更新可能有1-2分钟延迟")
    
    # 自动刷新逻辑
    if auto_refresh:
        time.sleep(refresh_interval)
        st.rerun()

if __name__ == "__main__":
    main()