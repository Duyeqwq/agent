import os
import asyncio
import subprocess
from pathlib import Path
from typing import List, Dict, Any
from dotenv import load_dotenv
#意图标签
# [NEED_REVISION]：告诉调度器“发现问题，需要回到 Engineer 修复”，避免 Reviewer/QA 自己改代码
# [REQUEST_INFO]：告诉调度器“信息不足，需要问 Userproxy 或 PM 补充”，防止自行脑补
# [TASK_COMPLETE]：告诉调度器“当前角色已完成本阶段工作，可以进入下一阶段”
# [NEXT=Role]：是强制路由指令，让 SelectorGroupChat 直接把话交给指定角色（例如 QA 通过后必须交给 Userproxy）
# 加载环境变量
load_dotenv()

from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_agentchat.agents import AssistantAgent, UserProxyAgent
from autogen_agentchat.teams import SelectorGroupChat  # 替换为支持动态路由的 SelectorGroupChat
from autogen_agentchat.conditions import TextMentionTermination
from autogen_agentchat.ui import Console, UserInputManager


OUTPUT_FILE_PATH = Path(__file__).parent / "output.py"


# ==========================================
# 1. 定义工具 (Tools)
# ==========================================
def save_output_code(code: str) -> str:
    """保存工程师生成的 Python 代码到 output.py。"""
    OUTPUT_FILE_PATH.write_text(code, encoding="utf-8")
    return f"代码已成功保存到 {OUTPUT_FILE_PATH}"

def run_python_script() -> str:
    """运行 output.py 并返回执行结果或错误信息。"""
    if not OUTPUT_FILE_PATH.exists():
        return "错误：找不到 output.py 文件，请确认工程师是否已保存代码。"
    
    try:
        # 运行代码，设置 10 秒超时防止死循环或阻塞
        result = subprocess.run(
            ["python", str(OUTPUT_FILE_PATH)], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        if result.returncode == 0:
            return f"✅ 代码执行成功。控制台输出:\n{result.stdout}"
        else:
            return f"❌ 代码执行报错。错误信息:\n{result.stderr}"
    except subprocess.TimeoutExpired:
        return "❌ 代码执行超时 (超过10秒)，可能存在死循环或未响应的阻塞操作。"
    except Exception as e:
        return f"❌ 执行环境发生异常: {str(e)}"


# ==========================================
# 2. 定义模型客户端
# ==========================================
def create_openai_model_client():
    """创建Openai模型客户端"""
    return OpenAIChatCompletionClient(
        model=os.getenv("LLM_MODEL_ID"),
        api_key=os.getenv("LLM_API_KEY"),
        base_url=os.getenv("LLM_BASE_URL"),
        model_info={
            "vision": False,
            "function_calling": True,
            "json_output": True,
            "family": "deepseek", # 如果你用的是 deepseek，保持不变；如果是 openai，可以去掉或改为对应 family
        }
    )


# ==========================================
# 3. 创建智能体 (添加了 description 用于动态路由)
# ==========================================
def create_product_manager(model_client):
    """创建产品经理智能体"""
    system_message = """你是一位经验丰富的产品经理，专门负责软件产品的需求分析和项目规划。
当接到开发任务时，请按以下结构进行分析：
1. 需求理解与分析
2. 功能模块划分
3. 技术选型建议
4. 实现优先级排序
5. 验收标准定义

请简洁明了地回应，并在分析完成后说"需求分析完毕，请工程师开始实现"。

【意图护栏】
- 回复前用1句复述“用户原始需求”，只保留与当前阶段相关的信息。
- 若发现当前话题与原始需求无直接关系，必须声明“检测到意图漂移”，并拉回主线。
- 严格遵守角色边界：只做本角色职责，禁止越权或代替他人完成任务。
- 禁止寒暄/夸赞，输出必须可执行或可验证。
- 末尾必须输出意图标签之一：[NEED_REVISION] / [REQUEST_INFO] / [TASK_COMPLETE]
- 末尾必须输出路由标签：[NEXT=ProductManager|Engineer|CodeReviewer|QAEngineer|Userproxy]

【角色约束】
- 只做需求分析/拆解/验收标准，禁止写代码、评审或测试。
- 信息不足时，提出1-2个必要问题。

【输出要求】
- 分析完成后必须以“需求分析完毕，请工程师开始实现”收尾，并输出 [TASK_COMPLETE][NEXT=Engineer]。
- 需要补充信息时输出 [REQUEST_INFO][NEXT=Userproxy]。"""
    
    return AssistantAgent(
        name="ProductManager",
        model_client=model_client,
        system_message=system_message,
        description="产品经理。负责需求分析、功能规划。当任务刚开始，或开发/测试过程中发现需求需要重新确认时，由该角色发言。"
    )


def create_engineer(model_client):
    """创建软件工程师智能体"""
    system_message = """你是一位资深的软件工程师，擅长 Python 开发和 Web 应用构建。
当收到开发需求，或者收到测试工程师的报错反馈时，请严格按以下流程执行：
1. 仔细分析需求或报错信息。
2. 编写完整的、修复后的可运行 Python 代码（仅输出代码内容，不要解释太多文本）。
3. 必须调用工具 `save_output_code(code)` 将代码写入 output.py。
4. 工具调用成功后，请明确回复："代码已更新，请代码审查员检查"。

【意图护栏】
- 回复前用1句复述“用户原始需求”，只保留与当前阶段相关的信息。
- 若发现当前话题与原始需求无直接关系，必须声明“检测到意图漂移”，并拉回主线。
- 严格遵守角色边界：只做本角色职责，禁止越权或代替他人完成任务。
- 禁止寒暄/夸赞，输出必须可执行或可验证。
- 末尾必须输出意图标签之一：[NEED_REVISION] / [REQUEST_INFO] / [TASK_COMPLETE]
- 末尾必须输出路由标签：[NEXT=ProductManager|Engineer|CodeReviewer|QAEngineer|Userproxy]

【角色约束】
- 只写可运行代码，禁止评审/测试/替用户做验收。
- 优先修复核心功能与错误，避免陷入无关细节。

【输出要求】
- 代码保存成功后必须输出“代码已更新，请代码审查员检查”并以 [TASK_COMPLETE][NEXT=CodeReviewer] 结尾。
- 需求不清时输出 [REQUEST_INFO][NEXT=ProductManager]。"""
    
    return AssistantAgent(
        name="Engineer",
        model_client=model_client,
        system_message=system_message,
        description="软件工程师。负责编写、修改和保存 Python 代码。当产品经理发布需求后，或收到代码审查未通过、测试报错需要修复时，由该角色发言。",
        tools=[save_output_code],
    )


def create_code_reviewer(model_client):
    """创建代码审查员智能体"""
    system_message = """你是一位经验丰富的代码审查员。
你的审查重点是代码的规范性、安全性和最佳实践（不负责实际运行测试）。
审查流程：
1. 仔细阅读工程师提交的代码逻辑。
2. 如果发现明显的语法错误、安全隐患或不符合规范的地方，指出问题并明确要求："审查未通过，请工程师重新修改"。
3. 如果代码从静态角度看没有问题，请明确回复："代码审查通过，请测试工程师(QA)进行执行测试"。

【意图护栏】
- 回复前用1句复述“用户原始需求”，只保留与当前阶段相关的信息。
- 若发现当前话题与原始需求无直接关系，必须声明“检测到意图漂移”，并拉回主线。
- 严格遵守角色边界：只做本角色职责，禁止越权或代替他人完成任务。
- 禁止寒暄/夸赞，输出必须可执行或可验证。
- 末尾必须输出意图标签之一：[NEED_REVISION] / [REQUEST_INFO] / [TASK_COMPLETE]
- 末尾必须输出路由标签：[NEXT=ProductManager|Engineer|CodeReviewer|QAEngineer|Userproxy]

【角色约束】
- 只做静态审查，禁止输出完整代码，禁止运行测试。
- 必须指出具体问题与位置，或明确说明未发现阻塞问题。

【输出要求】
- 发现问题：回复“审查未通过，请工程师重新修改”，并以 [NEED_REVISION][NEXT=Engineer] 结尾。
- 通过审查：回复“代码审查通过，请测试工程师(QA)进行执行测试”，并以 [TASK_COMPLETE][NEXT=QAEngineer] 结尾。
- 信息不足时输出 [REQUEST_INFO][NEXT=Engineer]。"""

    return AssistantAgent(
        name="CodeReviewer",
        model_client=model_client,
        system_message=system_message,
        description="代码审查员。当工程师写完并保存代码后，由该角色负责静态检查代码规范和逻辑盲点。",
    )


def create_qa_engineer(model_client):
    """创建测试工程师智能体"""
    system_message = """你是一位严谨的自动化测试工程师 (QA)。
你的核心职责是在代码审查员通过后，实际运行代码以验证其正确性。
执行流程：
1. 当轮到你发言时，必须调用工具 `run_python_script()` 执行工程师保存的代码。
2. 分析执行结果：
   - 如果遇到报错（Error/Exception/超时），提取关键报错信息，并明确回复："测试失败，请工程师根据以下报错进行修复：[附上报错信息]"。
    - 如果执行成功，未见报错，请明确回复："功能测试通过，请Userproxy进行最终验收"。

【意图护栏】
- 回复前用1句复述“用户原始需求”，只保留与当前阶段相关的信息。
- 若发现当前话题与原始需求无直接关系，必须声明“检测到意图漂移”，并拉回主线。
- 严格遵守角色边界：只做本角色职责，禁止越权或代替他人完成任务。
- 禁止寒暄/夸赞，输出必须可执行或可验证。
- 末尾必须输出意图标签之一：[NEED_REVISION] / [REQUEST_INFO] / [TASK_COMPLETE]
- 末尾必须输出路由标签：[NEXT=ProductManager|Engineer|CodeReviewer|QAEngineer|Userproxy]

【角色约束】
- 发言必须调用 `run_python_script()` 并引用关键输出。
- 只做测试反馈，禁止写代码或评审。

【输出要求】
- 测试失败：回复“测试失败，请工程师根据以下报错进行修复：[附上报错信息]”，并以 [NEED_REVISION][NEXT=Engineer] 结尾。
- 测试通过：回复“功能测试通过，请Userproxy进行最终验收”，并以 [TASK_COMPLETE][NEXT=Userproxy] 结尾。"""

    return AssistantAgent(
        name="QAEngineer",
        model_client=model_client,
        system_message=system_message,
        description="测试工程师。必须在代码审查员(CodeReviewer)认为代码没问题后发言，负责调用工具运行代码并反馈测试结果。",
        tools=[run_python_script], 
    )


def create_user_proxy(user_input_manager: UserInputManager):
    """创建用户代理智能体"""
    return UserProxyAgent(
        name="Userproxy",
        input_func=user_input_manager.get_wrapped_callback(),
        description="用户代理，代表真实人类用户。负责提出初始需求，以及在测试工程师宣布测试通过后，进行最终的验收。完成测试后必须回复 TERMINATE 结束对话。",
    )


# ==========================================
# 4. 运行团队协作流
# ==========================================
async def run_software_development_team():
    """运行软件开发团队协作流程"""
    print("🔧 正在初始化软件开发团队...")

    model_client = create_openai_model_client()

    print("👥 正在创建智能体团队...")
    user_input_manager = UserInputManager(callback=input)
    product_manager = create_product_manager(model_client)
    engineer = create_engineer(model_client)
    code_reviewer = create_code_reviewer(model_client)
    qa_engineer = create_qa_engineer(model_client)  # 新增测试角色
    user_proxy = create_user_proxy(user_input_manager)

    # 添加终止条件
    termination = TextMentionTermination(text="TERMINATE") 

    # 创建动态路由团队聊天 (SelectorGroupChat)
    team_chat = SelectorGroupChat(
        participants=[
            product_manager,
            engineer,
            code_reviewer,
            qa_engineer,
            user_proxy
        ],
        model_client=model_client, # Selector 需要模型来决策路由
        termination_condition=termination,
        max_turns=30, # 增加轮次以应对可能的“打回重写”循环
        selector_prompt="""你是一个团队协作调度员。请根据当前的对话历史和各个角色的 description，选择最适合接话的智能体。
路由规则：
1. 若上一条消息包含 [NEXT=Role]，必须直接路由到该 Role。
2. 如果上一条来自 Userproxy 且没有任何标签，交给 ProductManager。
3. 如果没有 [NEXT=...] 但有 [NEED_REVISION]，交给 Engineer。
4. 如果没有 [NEXT=...] 但有 [REQUEST_INFO]，交给 Userproxy。
5. 如果没有 [NEXT=...] 但有 [TASK_COMPLETE]，按标准流程继续：
   - ProductManager -> Engineer
   - Engineer -> CodeReviewer
   - CodeReviewer -> QAEngineer
   - QAEngineer -> Userproxy
6. 如果上一条来自非 Userproxy 且没有任何意图标签，路由回该角色，要求其按格式重答。
7. 【重要回退逻辑】：如果 CodeReviewer 提出修改意见，或 QAEngineer 测试出 Bug，必须立刻交回给 Engineer 修改代码！"""
    )

    task = """我们需要开发一个比特币价格显示应用，具体要求如下：
核心功能：
- 实时显示比特币当前价格（USD）
- 显示24小时价格变化趋势（涨跌幅和涨跌额）
- 提供价格刷新功能
技术要求：
- 使用 Streamlit 框架创建 Web 应用
- 界面简洁美观，用户友好
- 添加适当的错误处理和加载状态
请团队协作完成这个任务，从需求分析到最终实现。"""

    print("🚀 正在执行动态团队协作...")
    print("="*60)

    # 使用 console 来显示对话过程
    result = await Console(team_chat.run_stream(task=task), user_input_manager=user_input_manager)

    print("\n"+"="*60)
    return result


if __name__ =="__main__":
    try:
        # 运行异步协作流程
        result = asyncio.run(run_software_development_team())

        print(f"\n📋 协作结果摘要：")
        print(f"- 参与智能体数量：5个 (新增 QA)")
        print(f"- 任务完成状态：{'成功 (收到 TERMINATE)' if result else '达到最大轮次或被中断'}")

    except ValueError as e:
        print(f"❌ 配置错误：{e}")
        print("请检查 .env 文件中的配置是否正确")
    except Exception as e:
        print(f"❌ 运行错误：{e}")
        import traceback
        traceback.print_exc()
