from tool.calculator import calculate


def test_calculate_basic_ops():
    assert calculate("1+2*3") == "7"
    assert calculate("(10-3)/2") == "3.5"


def test_calculate_extended_ops():
    assert calculate("2^8") == "256"
    assert calculate("9%4") == "1"
    assert calculate("10÷2") == "5"


def test_calculate_error_cases():
    assert "除数不能为 0" in calculate("1/0")
    assert "语法不正确" in calculate("1+")
    assert "不支持" in calculate("abs(2)")