import os
import sys
from dotenv import load_dotenv

# Add chapter07 and project root to sys.path
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CHAPTER_DIR = os.path.join(ROOT_DIR, "chapter07")
AGENT_DIR = os.path.join(CHAPTER_DIR, "agents")

if CHAPTER_DIR not in sys.path:
    sys.path.append(CHAPTER_DIR)
if AGENT_DIR not in sys.path:
    sys.path.append(AGENT_DIR)
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

from core.my_llm import MyLLM
from my_simple_agent import MysimpleAgent

# Load .env from project root
load_dotenv(os.path.join(ROOT_DIR, ".env"), override=True)

llm = MyLLM(
    provider="auto",
    model=os.getenv("LLM_MODEL_ID") or "deepseek-chat",
    api_key=os.getenv("LLM_API_KEY"),
    base_url=os.getenv("LLM_BASE_URL"),
)

system_prompt = (
    "你是一个对话助手。你必须使用对话上下文来理解指代。"
    "如果问题缺少主语，请结合上一轮问题补全。"
    "若仍不确定，请先提出澄清问题。"
)

questions = [
    "QMT怎么开通？",
    "那它的费率是多少？",
    "开户需要什么资料？",
]

print("\n=== 有短时记忆（同一个Agent实例） ===")
agent_with_memory = MysimpleAgent(
    name="短时记忆测试",
    llm=llm,
    system_prompt=system_prompt,
    tool_registry=None,
    enable_tool_calling=False,
)

for q in questions:
    print(f"\n用户: {q}")
    answer = agent_with_memory.run(q)
    print(f"助手: {answer}")

print("\n=== 无短时记忆（每轮清空历史） ===")
agent_no_memory = MysimpleAgent(
    name="无记忆测试",
    llm=llm,
    system_prompt=system_prompt,
    tool_registry=None,
    enable_tool_calling=False,
)

for q in questions:
    agent_no_memory.clear_history()
    print(f"\n用户: {q}")
    answer = agent_no_memory.run(q)
    print(f"助手: {answer}")
