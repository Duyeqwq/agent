AGENT_SYSTEM_PROMPT = """
你是一个智能旅行助手。你的任务是分析用户的请求，并使用可用工具一步步地解决问题。

# 可用工具:
- `get_weather(city: str)`: 查询指定城市的实时天气。
- `get_attraction(city: str, weather: str)`: 根据城市和天气搜索推荐的旅游景点。

# 输出格式要求:
你的每次回复必须严格遵循以下格式，包含一对Thought和Action：

Thought: [你的思考过程和下一步计划]
Action: [你要执行的具体行动]

Action的格式必须是以下之一：
1. 调用工具：function_name(arg_name="arg_value")
2. 结束任务：Finish[最终答案]

# 重要提示:
- 每次只输出一对Thought-Action
- Action必须在同一行，不要换行
- 当收集到足够信息可以回答用户问题时，必须使用 Action: Finish[最终答案] 格式结束

请开始吧！
"""
import requests# 导入requests库，用于发起HTTP请求
def get_weather(city:str) ->str:
    """
    通过调用 wttr.in API 查询真实的天气信息。
    """
    #API端点，我们请求JSON格式的数据
    url = f"https://wttr.in/{city}?format=j1"
    try:
        #发起网络请求
        response = requests.get(url)
        #检查响应状态码是否为200 (成功)
        response.raise_for_status()
        #解析返回的JSON数据
        data = response.json()

        #提取当前天气状况
        """
        {
  "current_condition": [   <-- 这里是一个【列表】，用中括号 [] 表示
    {                      <-- 列表的第 0 个元素，是一个【字典】
      "temp_C": "25",
      "weatherDesc": [     <-- 这里又是一个【列表】
        {                  <-- 列表的第 0 个元素
          "value": "晴朗"
        }
      ]
    }
  ]
}

        """
        current_condition = data['current_condition'][0]
        weather_desc = current_condition['weatherDesc'][0]['value']
        temp_c = current_condition['temp_C']

        # 格式化成自然语言返回
        return f"{city}当前天气：{weather_desc}，气温{temp_c}摄氏度"
    except requests.exceptions.RequestException as e:
        # 处理网络错误
        return f"错误：查询天气时遇到网络问题 - {e}"
    except (KeyError, IndexError) as e:
        # 处理数据解析错误
        return f"错误：解析天气数据失败，可能是城市名称无效 - {e}"

import os
from tavily import TavilyClient
# 从环境变量中获取 Tavily API 密钥
def get_attraction(city:str,weather:str) ->str:
    """
    根据城市和天气，使用Tavily Search API搜索并返回优化后的景点推荐。
    """
    api_key = os.getenv("TAVILY_API_KEY")
    if not api_key:
        return "错误，未配置TAVILY_API_KEY"
    #初始化Tavily客户端
    tavily = TavilyClient(api_key=api_key)
    #构造一个精确的查询
    query = f"'{city}'在'{weather}'天气下最值得去的旅游景点推荐及理由"
    try:
        # 调用Tavily Search API，include_answer=True表示我们希望得到一个优化后的答案，而不仅仅是原始搜索结果
        response = tavily.search(query=query, search_depth="basic", include_answer=True)

        if response.get("answer"):
            return response["answer"]
        
        formatted_results= []
        for result in response.get("results",[]):
            formatted_results.append(f"- {result['title']} : {result['content']}")
        
        if not formatted_results:
            return "抱歉，没有找到相关的旅游景点推荐。"
        return "根据搜索，为您找到以下信息：\n" + "\n".join(formatted_results)
    except Exception as e:
        return f"错误，执行Tavily搜索时出现问题 - {e}"

#将所有工具函数放在一起，方便主程序调用
available_tools = {
    "get_weather":get_weather,
    "get_attraction":get_attraction
}

from openai import OpenAI

class OpenAICompatibleClient:
    """
    一个用于调用任何兼容OPENAI API的客户端，提供一个统一的接口。
            message = [
                {"role":"system","content":system_prompt},
                {"role":"user","content":prompt}
            ]
        为什么都这么喜欢写message，因为可以让AI更清楚的认清楚规则和问题
            system（系统）：
            定位：导演、编剧、设定者。
            作用：设定 AI 的人设、背景、规则。比如“你是一个翻译”或“你是一个 Python 专家”。
            特点：它的优先级通常最高，能全局控制模型的行为。
            user（用户）：
            定位：提问的人。
            作用：具体的任务指令或问题。比如“帮我写一段代码”。
            assistant（助手）：
            定位：AI 自己。
            作用：AI 之前的回复（用于多轮对话记忆）。

    """
    def __init__(self, model: str, api_key: str,base_url: str):
        self.model = model
        self.client = OpenAI(api_key=api_key,base_url=base_url)
    
    def generate(self, prompt: str, system_prompt: str) -> str:
        """调用LLM API来生成回应。"""
        print("正在调用大语言模型...")
        try:
            message = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ]
            response = self.client.chat.completions.create(
                model=self.model,
                messages=message,
                stream=False
            )
            answer = response.choices[0].message.content
            print("大语言模型响应成功。")
            return answer
        except Exception as e:
            print(f"调用LLM API时发生错误: {e}")
            return "错误：调用语言模型服务时出错。"

import re

# --- 1. 配置LLM客户端 ---
# 请根据您使用的服务，将这里替换成对应的凭证和地址
API_KEY = "sk-aa331bfd094646929fcc313c7dfbd3a1"
BASE_URL = "https://api.deepseek.com"
MODEL_ID = "deepseek-chat"
os.environ[ 'TAVILY_API_KEY'] = "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"

llm = OpenAICompatibleClient(
    model=MODEL_ID,
    api_key=API_KEY,
    base_url=BASE_URL
)
# --- 2. 初始化 ---
user_prompt = "你好，请帮我查询一下今天北京的天气，然后根据天气推荐一个合适的旅游景点。"
prompt_history = [f"用户请求: {user_prompt}"]
print(f"用户输入：{user_prompt}\n"+"="*40)

for i in range(5): # 设置最大循环次数
    print(f"--- 循环 {i+1} ---\n")
    full_prompt = "\n".join(prompt_history)

    llm_output = llm.generate(prompt=full_prompt, system_prompt=AGENT_SYSTEM_PROMPT)
    # 模型可能会输出多余的Thought-Action，需要截断
    match = re.search(r'(Thought:.*?Action:.*?)(?=\n\s*(?:Thought:|Action:|Observation:)|\Z)', llm_output, re.DOTALL)
    if match:
        truncated = match.group(1).strip()
        if truncated != llm_output.strip():
            llm_output = truncated
            print("已截断多余的 Thought-Action 对")
    print(f"模型输出:\n{llm_output}\n")
    prompt_history.append(llm_output)

    # 解析Action
    action_match = re.search(r"Action: (.*)", llm_output, re.DOTALL)
    if not action_match:
        observation = "错误: 未能解析到 Action 字段。请确保你的回复严格遵循 'Thought: ... Action: ...' 的格式。"
        observation_str = f"Observation: {observation}"
        print(f"{observation_str}\n" + "="*40)
        prompt_history.append(observation_str)
        continue
    action_str = action_match.group(1).strip()

    if action_str.startswith("Finish"):
        final_answer = re.match(r"Finish\[(.*)\]", action_str).group(1)
        print(f"任务完成，最终答案: {final_answer}")
        break
    
    tool_name = re.search(r"(\w+)\(", action_str).group(1)
    args_str = re.search(r"\((.*)\)", action_str).group(1)
    kwargs = dict(re.findall(r'(\w+)="([^"]*)"', args_str))

    if tool_name in available_tools:
        observation = available_tools[tool_name](**kwargs)
    else:
        observation = f"错误：未定义的工具 '{tool_name}'"

    observation_str = f"Observation: {observation}"
    print(f"{observation_str}\n" + "="*40)
    prompt_history.append(observation_str)