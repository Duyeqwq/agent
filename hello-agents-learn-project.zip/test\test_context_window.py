import os
import sys
from dotenv import load_dotenv

# Add chapter07 and project root to sys.path
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CHAPTER_DIR = os.path.join(ROOT_DIR, "chapter07")

if CHAPTER_DIR not in sys.path:
    sys.path.append(CHAPTER_DIR)
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

from core.my_llm import MyLLM

# Load .env from project root
load_dotenv(os.path.join(ROOT_DIR, ".env"), override=True)

llm = MyLLM(
    provider="auto",
    model=os.getenv("LLM_MODEL_ID") or "deepseek-chat",
    api_key=os.getenv("LLM_API_KEY"),
    base_url=os.getenv("LLM_BASE_URL"),
)

secret_code = os.getenv("TEST_SECRET_CODE") or "ALPHA-4392"

system_prompt = "You are a helpful assistant. Reply briefly and follow instructions."
base_messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": f"Remember this secret code: {secret_code}. Reply with ACK only."},
]

ack = llm.invoke(base_messages)
print(f"ACK response: {ack}")

base_messages.append({"role": "assistant", "content": ack})

# Approximate context window stress by adding large filler text
sizes = [200, 400, 800, 1200, 1600, 2400, 3200]

print("\n=== Context window probe ===")
for size in sizes:
    filler = ("lorem " * size).strip()
    user_message = (
        f"FILLER ({size} words): {filler}\n\n"
        "Question: What is the secret code? Reply only the code."
    )
    messages = base_messages + [{"role": "user", "content": user_message}]
    response = llm.invoke(messages)
    ok = secret_code in response
    print(f"size={size:>4} words | ok={ok} | reply={response}")
