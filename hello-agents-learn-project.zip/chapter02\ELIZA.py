
import re
import random
from googletrans import Translator

# 定义规则库:模式(正则表达式) -> 响应模板列表
rules = {
    r'I need (.*)': [
        "Why do you need {0}?",
        "Would it really help you to get {0}?",
        "Are you sure you need {0}?"
    ],
    r'Why don\'t you (.*)\?': [
        "Do you really think I don't {0}?",
        "Perhaps eventually I will {0}.",
        "Do you really want me to {0}?"
    ],
    r'Why can\'t I (.*)\?': [
        "Do you think you should be able to {0}?",
        "If you could {0}, what would you do?",
        "I don't know -- why can't you {0}?"
    ],
    r'I am (.*)': [
        "Did you come to me because you are {0}?",
        "How long have you been {0}?",
        "How do you feel about being {0}?"
    ],
    r'.* mother .*': [
        "Tell me more about your mother.",
        "What was your relationship with your mother like?",
        "How do you feel about your mother?"
    ],
    r'.* father .*': [
        "Tell me more about your father.",
        "How did your father make you feel?",
        "What has your father taught you?"
    ],
    r'My name is (.*)': [
        "Nice to meet you, {0}.",
        "Hello {0}, how can I help you today?"
    ],
    r'I am (\d+) years old': [
        "You are {0} years old. Age is just a number!",
        "{0} years old, got it. Does your age affect how you feel?"
    ],
    r'I work as a (.*)': [
        "Being a {0} sounds interesting. What do you like about your job?",
        "How long have you been working as a {0}?"
    ],
    r'I study (.*)': [
        "Why did you choose to study {0}?",
        "What do you enjoy most about studying {0}?"
    ],
    r'My hobby is (.*)': [
        "How did you get into {0}?",
        "What do you like about {0}?"
    ],
    r'.*': [
        "Please tell me more.",
        "Let's change focus a bit... Tell me about your family.",
        "Can you elaborate on that?"
    ]
}

# 定义代词转换规则
pronoun_swap = {
    "i": "you", "you": "i", "me": "you", "my": "your",
    "am": "are", "are": "am", "was": "were", "i'd": "you would",
    "i've": "you have", "i'll": "you will", "yours": "mine",
    "mine": "yours"
}

def swap_pronouns(phrase):
    """
    对输入短语中的代词进行第一/第二人称转换
    """
    words = phrase.lower().split()
    swapped_words = [pronoun_swap.get(word, word) for word in words]
    return " ".join(swapped_words)


# 上下文记忆功能
context_memory = {
    'name': None,
    'age': None,
    'job': None,
    'hobby': None
}

def respond(user_input):
    """
    根据规则库生成响应，并实现简单上下文记忆
    """
    # 先检查并存储关键信息
    name_match = re.search(r'My name is (.*)', user_input, re.IGNORECASE)
    if name_match:
        context_memory['name'] = name_match.group(1).strip().split()[0]
    age_match = re.search(r'I am (\d+) years old', user_input, re.IGNORECASE)
    if age_match:
        context_memory['age'] = age_match.group(1)
    job_match = re.search(r'I work as a (.*)', user_input, re.IGNORECASE)
    if job_match:
        context_memory['job'] = job_match.group(1).strip().split()[0]
    hobby_match = re.search(r'My hobby is (.*)', user_input, re.IGNORECASE)
    if hobby_match:
        context_memory['hobby'] = hobby_match.group(1).strip().split()[0]

    # 处理上下文引用
    if 'name' in user_input.lower() and context_memory['name']:
        return f"You told me your name is {context_memory['name']}."
    if 'age' in user_input.lower() and context_memory['age']:
        return f"You mentioned you are {context_memory['age']} years old."
    if 'job' in user_input.lower() and context_memory['job']:
        return f"You said you work as a {context_memory['job']}."
    if 'hobby' in user_input.lower() and context_memory['hobby']:
        return f"Your hobby is {context_memory['hobby']}, right?"

    # 正常规则匹配
    for pattern, responses in rules.items():
        match = re.search(pattern, user_input, re.IGNORECASE)
        if match:
            captured_group = match.group(1) if match.groups() else ''
            swapped_group = swap_pronouns(captured_group)
            response = random.choice(responses).format(swapped_group)
            return response
    return random.choice(rules[r'.*'])


# 主聊天循环，自动翻译用户输入为英文
if __name__ == '__main__':
    translator = Translator()
    print("Therapist: Hello! How can I help you today? (You can speak Chinese or English)")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["quit", "exit", "bye"]:
            print("Therapist: Goodbye. It was nice talking to you.")
            break
        # 自动翻译为英文
        translated = translator.translate(user_input, dest='en').text
        response = respond(translated)
        print(f"Therapist: {response}")
        
