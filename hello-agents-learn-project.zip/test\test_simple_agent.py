# test_simple_agent.py
import os
import sys

# 添加 chapter07 与 agents 到 Python 路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'chapter07'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'chapter07', 'agents'))


from dotenv import load_dotenv
from hello_agents import ToolRegistry
from hello_agents.tools import CalculatorTool
from core.my_llm import MyLLM
from my_simple_agent import MysimpleAgent as MySimpleAgent

# 加载环境变量（显式读取项目根目录 .env，并覆盖当前 shell 的旧变量）
load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'), override=True)

# 创建LLM实例（使用支持 modelscope 的自定义 MyLLM）
llm = MyLLM(provider=os.getenv("LLM_PROVIDER"), model=os.getenv("ACTIVE_MODEL_ID"))

# 测试1:基础对话Agent（无工具）
print("=== 测试1:基础对话 ===")
basic_agent = MySimpleAgent(
    name="基础助手",
    llm=llm,
    system_prompt="你是一个友好的AI助手，请用简洁明了的方式回答问题。"
)

response1 = basic_agent.run("你好，请介绍一下自己")
print(f"基础对话响应: {response1}\n")

# 测试2:带工具的Agent
print("=== 测试2:工具增强对话 ===")
tool_registry = ToolRegistry()
calculator = CalculatorTool()
tool_registry.register_tool(calculator)

enhanced_agent = MySimpleAgent(
    name="增强助手",
    llm=llm,
    system_prompt="你是一个智能助手，可以使用工具来帮助用户。",
    tool_registry=tool_registry,
    enable_tool_calling=True
)

response2 = enhanced_agent.run("请帮我计算一个长方体的体积。长为 123.45 厘米，宽为 67.89 厘米，高为 45.67 厘米。请直接给出最终的体积数值结果，保留两位小数。")
print(f"工具增强响应: {response2}\n")

# 测试3:流式响应
print("=== 测试3:流式响应 ===")
print("流式响应: ", end="")
for _ in basic_agent.stream_run("请解释什么是人工智能"):
    pass

# 测试4:动态添加工具
print("\n=== 测试4:动态工具管理 ===")
print(f"添加工具前: {basic_agent.has_tools()}")
basic_agent.add_tool(calculator)
print(f"添加工具后: {basic_agent.has_tools()}")
print(f"可用工具: {basic_agent.list_tools()}")

# 查看对话历史
print(f"\n对话历史: {len(basic_agent.get_history())} 条消息")
