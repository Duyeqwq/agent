import re
import collections

def get_stats(vocab):
    """
    统计词表中所有相邻符号对的出现频率。
    
    参数:
        vocab: dict, 键是空格分隔的符号字符串(如 'h u g </w>')，值是该词的出现频率。
    
    返回:
        pairs: dict, 键是符号对元组(如 ('u', 'g'))，值是该对出现的总频率。
    """
    pairs = collections.defaultdict(int) # 初始化一个字典，如果键不存在则默认值为0
    
    for word, freq in vocab.items():
        symbols = word.split() # 将字符串 'h u g </w>' 拆分成列表 ['h', 'u', 'g', '</w>']
        
        # 遍历列表中所有相邻的位置
        for i in range(len(symbols)-1):
            # 获取相邻的两个符号
            current_pair = (symbols[i], symbols[i+1])
            # 累加这对符号的频率
            pairs[current_pair] += freq
            
    return pairs

def merge_vocab(pair, v_in):
    """
    在词表中合并指定的符号对。
    
    参数:
        pair: tuple, 要合并的符号对，例如 ('u', 'g')。
        v_in: dict, 合并前的词表。
        
    返回:
        v_out: dict, 合并后的新词表。
    """
    v_out = {}
    
    # 1. 准备正则表达式模式
    # 将元组 ('u', 'g') 转换为字符串 'u g'
    bigram = re.escape(' '.join(pair)) 
    # re.escape 用于转义特殊字符（虽然本例中没有特殊字符，但在处理如 '.' 等正则元字符时很必要）
    
    # 2. 编译正则表达式
    # r'(?<!\S)' : 左边不能是非空白字符（即左边必须是空白或字符串开头）
    # r'(?!\S)'  : 右边不能是非空白字符（即右边必须是空白或字符串结尾）
    # 这个模式确保了我们匹配的是独立的 token "u g"，而不是类似 "q u g" 中的一部分
    p = re.compile(r'(?<!\S)' + bigram + r'(?!\S)')
    
    # 3. 遍历词表进行替换
    for word in v_in:
        # 将匹配到的 "u g" 替换为 "ug" (去掉了中间的空格)
        w_out = p.sub(''.join(pair), word)
        v_out[w_out] = v_in[word] # 保持词频不变，更新到新词表
        
    return v_out

# --- 主程序开始 ---

# 准备语料库
# 1. 每个单词被切分成字符序列。
# 2. 每个词末尾加上特殊符号 </w>，表示单词结束。
#    这样做是为了让模型区分 "hug" (词尾) 和 "hugging" (词中) 的区别。
vocab = {
    'h u g </w>': 1, 
    'p u g </w>': 1, 
    'p u n </w>': 1, 
    'b u n </w>': 1
}

num_merges = 4 # 设置迭代合并的次数

print("初始词表:", list(vocab.keys()))
print("-" * 20)

for i in range(num_merges):
    # 第一步：统计所有相邻对的频率
    pairs = get_stats(vocab)
    
    if not pairs:
        break
    
    # 第二步：找出频率最高的对
    # key=pairs.get 告诉 max 函数依据字典的值(频率)来寻找最大值
    best = max(pairs, key=pairs.get)
    
    # 第三步：合并最高频的对，生成新词表
    vocab = merge_vocab(best, vocab)
    
    print(f"第{i+1}次合并: {best} -> {''.join(best)}")
    print(f"新词表: {list(vocab.keys())}")
    print("-" * 20)
