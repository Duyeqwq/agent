# my_simple_agent.py
import sys
import os

# 获取当前文件所在文件夹的父目录，即 chapter07
CHAPTER_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
# 获取项目根目录，即 hello-agents-learn
ROOT_DIR = os.path.abspath(os.path.join(CHAPTER_DIR, ".."))

# 将两个关键目录都加入路径
if CHAPTER_DIR not in sys.path:
    sys.path.append(CHAPTER_DIR) # 这样能找到 core
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)    # 这样能找到 tool

from typing import Optional, Iterator
try:
    from hello_agents import HelloAgentsLLM, Config, Message
except ImportError:
    # 如果作为独立脚本运行，直接从 core 导入
    from core.my_llm import HelloAgentsLLM
    from core.config import Config
    from core.message import Message

from core.agent import Agent        # 引入你手写的基类
import re 
class MysimpleAgent(Agent):
    """
    重写的简单对话Agent
    展示如何基于框架基类构建一个自定义Agent
    """
    def __init__(
            self,
            name:str,
            llm:HelloAgentsLLM,
            system_prompt:Optional[str] = None,
            config:Optional[Config] = None,
            tool_registry:Optional[dict] = None,
            enable_tool_calling:bool = True
    ):
        super().__init__(name,llm,system_prompt,config)
        self.tool_registry = tool_registry 
        self.enable_tool_calling = enable_tool_calling and tool_registry is not None

    def run(self,input_text:str,max_tool_iterations:int = 3,**kwargs) ->str:
        """
        重写的运行方法，支持工具调用
        """
        print(f"🔍 [调试] enable_tool_calling的值是: {self.enable_tool_calling}")  # 加这一行！
        print(f"{self.name}正在处理:{input_text}")
        #构建初始消息列表
        messages = []

        #添加系统消息（可能包含工具信息）
        enhanced_system_prompt = self._get_enhanced_system_prompt()
        messages.append({"role":"system","content":enhanced_system_prompt})

        #添加历史消息
        for msg in self._history:
            messages.append({"role":msg.role,"content":msg.content})
        
        #添加当前用户输入
        messages.append({"role":"user","content":input_text})

        #如果没有启用工具调用，使用简单的对话逻辑
        if not self.enable_tool_calling:
            response = self.llm.invoke(messages,**kwargs)
            self.add_message(Message(input_text,"user"))
            self.add_message(Message(response,"assistant"))
            print(f"{self.name}响应完成")
            return response
        #支持多轮工具调用的逻辑
        return self._run_with_tools(messages,input_text,max_tool_iterations,**kwargs)
    def _get_enhanced_system_prompt(self) -> str:
        """
        构建增强的系统提示，包含工具信息
        """
        base_prompt = self.system_prompt or "你是一个有用的AI助手。"
        if not self.enable_tool_calling or not self.tool_registry:
            return base_prompt

        tools_section = "\n你可以使用以下工具:\n"
        
        # 【加】下面这两行，把真实工具列出来
        for tool_name in self.tool_registry.list_tools():
            tools_section += f"- {tool_name}\n"
        
        tools_section += "你可以使用格式来调用工具来帮助回答：\n"
        tools_section += "'[TOOL_CALL:{tool_name}:{parameters}]'\n"
        
        # 【改】下面这行例子，换成真实的工具名
        example = self.tool_registry.list_tools()[0] if self.tool_registry.list_tools() else "tool_name"
        tools_section += f"例如:`[TOOL_CALL:{example}:具体参数]`\n\n"
        
        tools_section += "工具调用结果会自动插入到对话中，然后你可以基于结果继续回答。\n"
        return base_prompt + tools_section

    def _run_with_tools(self,messages:list,input_text:str,max_tool_iterations:int,**kwargs) -> str:
        """"支持工具调用的运行逻辑"""
        current_iteration = 0
        final_response = ""

        while current_iteration <max_tool_iterations:
            #调用大模型
            response = self.llm.invoke(messages,**kwargs)
            #检查是否有工具调用
            tool_calls = self._parse_tool_calls(response)
            if tool_calls:
                #解析工具调用
                print(f"🔧 检测到 {len(tool_calls)} 个工具调用")
                tool_results = []
                clean_response = response
                for call in tool_calls:
                    result = self._execute_tool_call(call['tool_name'], call['parameters'])
                    tool_results.append(result)
                    #从响应中移除工具调用标记
                    clean_response = clean_response.replace(call['original'],"")
                

                #构建包含工具结果的消息
                messages.append({"role":"assistant","content":clean_response})

                #添加工具结果
                tool_results_text = "\n\n".join(tool_results)
                messages.append({"role":"user","content":f"工具调用结果:\n{tool_results_text}\n\n请基于这些结果给出完整的回答。"})

                current_iteration += 1
                continue

            #没有工具调用，返回最终响应
            final_response = response
            break
        #如果达到最大工具调用次数，返回当前响应
        if current_iteration >= max_tool_iterations and not final_response:
            final_response = self.llm.invoke(messages,**kwargs)
        
        #保存到历史记录
        self.add_message(Message(input_text,"user"))
        self.add_message(Message(final_response,"assistant"))
        print(f"{self.name}响应完成")

        return final_response
    
    def _parse_tool_calls(self,text:str) -> list:
        """
        解析文本中的工具调用标记，返回工具调用列表
        """
        pattern = r'\[TOOL_CALL:(\w+):([^\]]+)\]'
        matches = re.findall(pattern,text)

        tool_calls = []
        for tool_name, parameters in matches:
            tool_calls.append({
                "tool_name":tool_name.strip(),
                "parameters":parameters.strip(),
                "original":f'[TOOL_CALL:{tool_name}:{parameters}]'
            })
        return tool_calls
    
    def _execute_tool_call(self,tool_name:str,parameters:str) -> str:
        """
        执行工具调用
        """
        if not self.tool_registry:
            return f"错误：未配置工具注册表"
        try:
            # 优先从 tool_registry 获取工具函数
            # 兼容 ToolExecutor 的 getTool 方法名
            tool_func = None
            if hasattr(self.tool_registry, 'getTool'):
                tool_func = self.tool_registry.getTool(tool_name)
            elif hasattr(self.tool_registry, 'get_tool'):
                tool_func = self.tool_registry.get_tool(tool_name)

            if tool_func:
                # 【加这两行照妖镜】
                print(f"🔍 获取到的工具类型: {type(tool_func)}")
                print(f"🔍 工具拥有的方法: {[m for m in dir(tool_func) if not m.startswith('_')]}")
                # 【加这一行！】看看它到底要什么格式的字典
                print(f"🔍 工具参数说明书: {tool_func.get_parameters()}") 
                if 'calculator' in tool_name.lower() or 'calculate' in tool_name.lower():
                    result = tool_func.run({"input": parameters})  # ✅ 包成字典
                else:
                    # 其他工具尝试智能解析参数
                    param_dict = self._parse_tool_parameters(tool_name, parameters)
                    # 如果工具接收字典，传字典；否则传原始参数
                    try:
                        result = tool_func(param_dict)
                    except:
                        result = tool_func(parameters)
                return f"工具 '{tool_name}' 调用结果:\n{result}"
            
            return f"错误：工具 '{tool_name}' 未找到"
        except Exception as e:
            print(f"❌ [工具报错抓捕] {tool_name} 失败了，原因是: {str(e)}") # 加这一行！
            return f"工具 '{tool_name}' 调用失败，错误信息: {str(e)}"
    def _parse_tool_parameters(self,tool_name:str,parameters:str) -> dict:
        """
        智能解析工具参数
        """
        param_dict = {}
        if '=' in parameters:
            # 格式: key=value 或 action=search,query=Python
            if ',' in parameters:
                #多个参数： action=search,query=Python，limit = 3
                pairs = parameters.split(',')
                for pair in pairs:
                    if '=' in pair:
                        key, value = pair.split('=',1)
                        param_dict[key.strip()] = value.strip()
            else:
                #单个参数： query  = Python
                key, value = parameters.split('=',1)
                param_dict[key.strip()] = value.strip()
        else:
            #直接传入参数，根据工具类型智能推断
            if tool_name == 'search':
                param_dict = {'query':parameters}
            elif tool_name == 'memory':
                param_dict = {'action':'search','query':parameters}
            else:
                param_dict = {'input':parameters}
        return param_dict
    
    def stream_run(self,input_text:str,max_tool_iterations:int = 3,**kwargs) -> Iterator[str]:
        """
        支持工具调用的流式运行逻辑
        """
        print(f"{self.name}正在处理:{input_text}")

        messages = []

        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        for msg in self._history:
            messages.append({"role": msg.role, "content": msg.content})
        messages.append({"role": "user", "content": input_text})

        #流式调用大模型
        full_response = ""
        print("实时响应",end = "")
        for chunk in self.llm.stream_invoke(messages,**kwargs):
            full_response += chunk
            print(chunk,end="",flush = True)
            yield chunk
        
        print("\n响应完成")
        #保存到历史记录
        self.add_message(Message(input_text,"user"))
        self.add_message(Message(full_response,"assistant"))
        print(f"{self.name}响应完成")

    def add_tool(self, tool) -> None:
        """添加工具到Agent（便利方法）"""
        if not self.tool_registry:
            from hello_agents import ToolRegistry
            self.tool_registry = ToolRegistry()
            self.enable_tool_calling = True

        self.tool_registry.register_tool(tool)
        print(f"🔧 工具 '{tool.name}' 已添加")

    def has_tools(self) -> bool:
        """检查是否有可用工具"""
        return self.enable_tool_calling and self.tool_registry is not None
    
    def remove_tool(self, tool_name: str) -> bool:
        """移除工具（便利方法）"""
        if self.tool_registry:
            self.tool_registry.unregister(tool_name)
            return True
        return False
    
    def list_tools(self) -> list:
        """列出所有可用工具"""
        if self.tool_registry:
            return self.tool_registry.list_tools()
        return []

