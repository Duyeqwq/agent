import os
import sys
import ast

# Compatibility shim for Python 3.12+ where ast.Num was removed.
if not hasattr(ast, "Num"):
    ast.Num = ast.Constant

# 添加 chapter07 和 agents 目录到 Python 路径
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CHAPTER_DIR = os.path.join(ROOT_DIR, "chapter07")
AGENT_DIR = os.path.join(CHAPTER_DIR, "agents")

if CHAPTER_DIR not in sys.path:
    sys.path.append(CHAPTER_DIR)
if AGENT_DIR not in sys.path:
    sys.path.append(AGENT_DIR)
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

from hello_agents import ToolRegistry
from hello_agents.tools.builtin.calculator import CalculatorTool
from core.my_llm import MyLLM
from my_react_agent import MyReActAgent

from dotenv import load_dotenv
# 显式加载根目录的 .env 文件
load_dotenv(os.path.join(ROOT_DIR, ".env"), override=True)

# 1. 初始化 LLM (使用项目自定义 MyLLM，避免走到无效的 MODELSCOPE_API_KEY)
llm = MyLLM(
    provider="auto",
    model=os.getenv("LLM_MODEL_ID") or "deepseek-chat",
    api_key=os.getenv("LLM_API_KEY"),
    base_url=os.getenv("LLM_BASE_URL"),
)

# 2. 初始化工具并注册
calculator = CalculatorTool()
registry = ToolRegistry()
# 修正方法名为 register_tool
registry.register_tool(calculator)

# 3. 实例化你写的 ReAct Agent
def error_callback(info: dict) -> str | None:
    print(f"⚠️ error_callback 捕获: {info}")
    return None

agent = MyReActAgent(
    name="数学小能手",
    llm=llm,
    tool_registry=registry,
    max_steps=5,  # 最多允许思考+行动 5 轮
    error_callback=error_callback,
)

# 4. 开始测试！(给一个必须用计算器的题)
question = "请问 123.45 乘以 67.89 再加上 100 等于多少？"
print(f"\n❓ 提问: {question}")

final_answer = agent.run(question)

print("\n" + "="*40)
print(f"🏁 最终答案: {final_answer}")
print("="*40)
