

import os,sys
if __package__ is None or __package__ == "":
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from chapter04.llm_api import HelloAgentsLLM
from tool.tool_exceutor import ToolExecutor

from typing import List,Dict,Any,Optional

class Memory:
    """
    一个简单的短时记忆模块，用于存储智能体的行动与反思轨迹。
    """
    def __init__(self):
        """
        初始化一个空列表来存储所有记录
        """
        self.record:List[Dict[str,Any]] = []
    
    def add_record(self,record_type:str,content:Any):
        """
        添加一个新的记录到记忆中。
        -record_type: str, 记录的类型，如 "thought", "action", "observation" 等。
        -content: Any, 记录的内容，可以是字符串、字典或任何其他数据结构。
        """
        record = {"type": record_type, "content": content}
        self.record.append(record)
        print(f"记忆更新: {record_type} -> {content}")

    def get_trajectory(self) ->str:
        """
        所有记忆记录格式化为一个连贯的字符串文本，用于构建提示词。
        """
        trajectory_parts = []
        for rec in self.record:
            if rec["type"] == "execution":
                trajectory_parts.append(f"----上一轮尝试（代码）--\n{rec['content']}")
            
            elif rec["type"] == "reflection":
                trajectory_parts.append(f"---评审员反馈----、n{rec['content']}")
            
        return "\n".join(trajectory_parts)

    def get_last_execution(self) -> Optional[str]:
        """
        获取最近一次的执行记录内容，如果没有则返回None。
        """
        for rec in reversed(self.record):
            if rec['type'] == 'execution':
                return rec['content']
        return None

#下面开始写reflection智能体

INITIAL_PROMPT_TEMPLATE = """
你是一位资深的Python程序员。请根据以下要求，编写一个Python函数。
你的代码必须包含完整的函数签名、文档字符串，并遵循PEP 8编码规范。

要求: {task}

请直接输出代码，不要包含任何额外的解释。
"""

REFLECT_PROMPT_TEMPLATE = """
你是一位极其严格的代码评审专家和资深算法工程师，对代码的性能有极致的要求。
你的任务是审查以下Python代码，并专注于找出其在<strong>算法效率</strong>上的主要瓶颈。

# 原始任务:
{task}

# 待审查的代码:
```python
{code}
```

请分析该代码的时间复杂度，并思考是否存在一种<strong>算法上更优</strong>的解决方案来显著提升性能。
如果存在，请清晰地指出当前算法的不足，并提出具体的、可行的改进算法建议（例如，使用筛法替代试除法）。
如果代码在算法层面已经达到最优，才能回答“无需改进”。

请直接输出你的反馈，不要包含任何额外的解释。
"""


REFINE_PROMPT_TEMPLATE = """
你是一位资深的Python程序员。你正在根据一位代码评审专家的反馈来优化你的代码。

# 原始任务:
{task}

# 你上一轮尝试的代码:
{last_code_attempt}
评审员的反馈：
{feedback}

请根据评审员的反馈，生成一个优化后的新版本代码。
你的代码必须包含完整的函数签名、文档字符串，并遵循PEP 8编码规范。
请直接输出优化后的代码，不要包含任何额外的解释。
"""

class ReflectionAgent:
    def __init__(self,llm_client:Any,max_iteration=3):
        self.llm_client = llm_client
        self.memory = Memory()
        self.max_iteration = max_iteration
    def _get_llm_response(self, prompt: str) -> str:
            """一个辅助方法，用于封装大模型，调用LLM并获取完整的流式响应。"""
            messages = [{"role": "user", "content": prompt}]
            response_text = self.llm_client.think(message=messages) or ""
            return response_text
    
    def run(self,task:str):
        print(f"--- 任务: {task} ---")

        # 1. 初始代码生成
        print("--- 正在初始尝试 ---")
        initial_prompt = INITIAL_PROMPT_TEMPLATE.format(task=task)
        inital_code = self.llm_client.think(message=[{"role": "user", "content": initial_prompt}])
        self.memory.add_record("execution", inital_code)

        # 2. 反思与优化循环
        for  i in range(self.max_iteration):
            print(f'--- 第 {i+1} 轮反思与优化 ---')

            #a.反思
            last_code = self.memory.get_last_execution()
            reflect_prompt = REFLECT_PROMPT_TEMPLATE.format(task=task,code=last_code)
            feedback = self._get_llm_response(reflect_prompt)
            self.memory.add_record("reflection",feedback)

            #b.检查是否需要停止
            if "无需改进" in feedback:
                print("\n 反思认为代码无需改进，任务完成")
                break
            #c.优化
            print("\n正在优化代码...")
            refine_prompt = REFINE_PROMPT_TEMPLATE.format(
                task=task,
                last_code_attempt=last_code,
                feedback=feedback
            )
            refined_code = self._get_llm_response(refine_prompt)
            self.memory.add_record("execution", refined_code)
        final_code = self.memory.get_last_execution()
        print(f"\n--- 任务完成 ---\n最终生成的代码:\n```python\n{final_code}\n```")
        return final_code
    
# --- 下面是一个使用示例 ---
if __name__ == "__main__":
    llm_client = HelloAgentsLLM()
    agent = ReflectionAgent(llm_client)

    # 定义一个需要优化的算法任务
    task = "编写一个Python函数，找出1到n之间所有的素数 (prime numbers)。要求算法效率尽可能高。"

    # 运行智能体来完成这个任务
    agent.run(task)