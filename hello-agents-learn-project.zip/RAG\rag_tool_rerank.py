"""RAGTool 二次开发版本

作用：在不修改第三方包的前提下，为检索结果增加 rerank 重排能力，提升召回排序质量。
rerank重排：在向量检索拿到一批候选后，再用一个“更精细但更慢”的模型，把“问题 + 每条候选”拼在一起做相关性打分，然后按这个分数重新排序。
"""

from typing import Dict, Any, List, Optional

from hello_agents.tools.builtin.rag_tool import RAGTool
from hello_agents.tools.base import ToolParameter
from hello_agents.memory.rag.pipeline import rerank_with_cross_encoder


class RerankRAGTool(RAGTool):
    """带 rerank 能力的 RAG 工具

    作用说明：
    - 在原始向量检索结果基础上，引入 cross-encoder 重排
    - 保持原有 RAGTool 的接口与行为，仅增强排序效果
    """

    def get_parameters(self) -> List[ToolParameter]:
        params = super().get_parameters()
        params.extend(
            [
                ToolParameter(
                    name="rerank",
                    type="boolean",
                    description="是否启用 rerank 重排（默认：true）",
                    required=False,
                    default=True,
                ),
                ToolParameter(
                    name="rerank_model",
                    type="string",
                    description="cross-encoder 重排模型名称",
                    required=False,
                    default="BAAI/bge-reranker-v2-m3",
                ),
                ToolParameter(
                    name="candidate_pool_multiplier",
                    type="integer",
                    description="候选池扩大倍数（默认：4）",
                    required=False,
                    default=4,
                ),
            ]
        )
        return params

    def _preprocess_parameters(self, action: str, **kwargs) -> Dict[str, Any]:
        kwargs = super()._preprocess_parameters(action, **kwargs)
        defaults = {
            "rerank": True,
            "rerank_model": "BAAI/bge-reranker-v2-m3",
            "candidate_pool_multiplier": 4,
        }
        for key, value in defaults.items():
            if key not in kwargs or kwargs[key] is None:
                kwargs[key] = value
        return kwargs

    def _attach_content_for_rerank(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """为 rerank 准备内容字段（将 metadata.content 提升为顶层 content）"""
        normalized = []
        for item in items or []:
            content = item.get("content")
            if not content:
                meta = item.get("metadata", {})
                content = meta.get("content", "")
            if content and "content" not in item:
                patched = dict(item)
                patched["content"] = content
                normalized.append(patched)
            else:
                normalized.append(item)
        return normalized

    def _retrieve_with_rerank(
        self,
        query: str,
        limit: int,
        enable_advanced_search: bool,
        min_score: float,
        namespace: Optional[str],
        rerank: bool,
        rerank_model: str,
        candidate_pool_multiplier: int,
    ) -> List[Dict[str, Any]]:
        """检索 + rerank 的统一入口"""
        pipeline = self._get_pipeline(namespace)

        pool_multiplier = max(1, int(candidate_pool_multiplier or 1))
        top_k = max(limit, limit * pool_multiplier)

        if enable_advanced_search:
            results = pipeline["search_advanced"](
                query=query,
                top_k=top_k,
                enable_mqe=True,
                enable_hyde=True,
                score_threshold=min_score if min_score > 0 else None,
            )
        else:
            results = pipeline["search"](
                query=query,
                top_k=top_k,
                score_threshold=min_score if min_score > 0 else None,
            )

        results = self._attach_content_for_rerank(results)

        if rerank:
            if not any(item.get("content") for item in results):
                return results[:limit]
            return rerank_with_cross_encoder(
                query=query,
                items=results,
                model_name=rerank_model,
                top_k=limit,
            )

        return results[:limit]

    def _search(
        self,
        query: str,
        limit: int = 5,
        min_score: float = 0.1,
        enable_advanced_search: bool = True,
        max_chars: int = 1200,
        include_citations: bool = True,
        namespace: Optional[str] = None,
        rerank: bool = True,
        rerank_model: str = "BAAI/bge-reranker-v2-m3",
        candidate_pool_multiplier: int = 4,
        **kwargs,
    ) -> str:
        """搜索知识库（带 rerank 重排）"""
        try:
            if not query or not query.strip():
                return "❌ 搜索查询不能为空"

            results = self._retrieve_with_rerank(
                query=query,
                limit=limit,
                enable_advanced_search=enable_advanced_search,
                min_score=min_score,
                namespace=namespace,
                rerank=rerank,
                rerank_model=rerank_model,
                candidate_pool_multiplier=candidate_pool_multiplier,
            )

            if not results:
                return f"🔍 未找到与 '{query}' 相关的内容"

            search_result = ["搜索结果："]
            for i, result in enumerate(results, 1):
                meta = result.get("metadata", {})
                vector_score = float(result.get("score", 0.0))
                rerank_score = result.get("rerank_score")
                content = meta.get("content", "")[:200] + "..."
                source = meta.get("source_path", "unknown")

                def clean_text(text):
                    try:
                        return str(text).encode("utf-8", errors="ignore").decode("utf-8")
                    except Exception:
                        return str(text)

                clean_content = clean_text(content)
                clean_source = clean_text(source)

                score_text = f"向量: {vector_score:.3f}"
                if rerank_score is not None:
                    score_text += f" | rerank: {float(rerank_score):.3f}"
                search_result.append(f"\n{i}. 文档: **{clean_source}** ({score_text})")
                search_result.append(f"   {clean_content}")

                if include_citations and meta.get("heading_path"):
                    clean_heading = clean_text(str(meta["heading_path"]))
                    search_result.append(f"   章节: {clean_heading}")

            return "\n".join(search_result)

        except Exception as e:
            return f"❌ 搜索失败: {str(e)}"

    def _ask(
        self,
        question: Optional[str] = None,
        query: Optional[str] = None,
        limit: int = 5,
        min_score: float = 0.1,
        enable_advanced_search: bool = True,
        include_citations: bool = True,
        max_chars: int = 1200,
        namespace: Optional[str] = None,
        rerank: bool = True,
        rerank_model: str = "BAAI/bge-reranker-v2-m3",
        candidate_pool_multiplier: int = 4,
        **kwargs,
    ) -> str:
        """智能问答：检索 + rerank + 生成"""
        try:
            user_question = question or query
            if not user_question or not user_question.strip():
                return "❌ 请提供要询问的问题"

            user_question = user_question.strip()
            print(f"🔍 智能问答: {user_question}")

            results = self._retrieve_with_rerank(
                query=user_question,
                limit=limit,
                enable_advanced_search=enable_advanced_search,
                min_score=min_score,
                namespace=namespace,
                rerank=rerank,
                rerank_model=rerank_model,
                candidate_pool_multiplier=candidate_pool_multiplier,
            )

            if not results:
                return (
                    f"🤔 抱歉，我在知识库中没有找到与「{user_question}」相关的信息。\n\n"
                    f"💡 建议：\n"
                    f"• 尝试使用更简洁的关键词\n"
                    f"• 检查是否已添加相关文档\n"
                    f"• 使用 stats 操作查看知识库状态"
                )

            context_parts = []
            citations = []
            total_score = 0.0

            for i, result in enumerate(results):
                meta = result.get("metadata", {})
                content = meta.get("content", "").strip()
                source = meta.get("source_path", "unknown")
                score = result.get("rerank_score", result.get("score", 0.0))
                total_score += float(score)

                if content:
                    cleaned_content = self._clean_content_for_context(content)
                    context_parts.append(f"片段 {i + 1}：{cleaned_content}")

                    if include_citations:
                        citations.append(
                            {
                                "index": i + 1,
                                "source": source,
                                "score": score,
                            }
                        )

            context = "\n\n".join(context_parts)
            if len(context) > max_chars:
                context = self._smart_truncate_context(context, max_chars)

            system_prompt = self._build_system_prompt()
            user_prompt = self._build_user_prompt(user_question, context)

            enhanced_prompt = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]

            answer = self.llm.invoke(enhanced_prompt)
            if not answer or not answer.strip():
                return "❌ LLM未能生成有效答案，请稍后重试"

            final_answer = self._format_final_answer(
                question=user_question,
                answer=answer.strip(),
                citations=citations if include_citations else None,
                search_time=0,
                llm_time=0,
                avg_score=total_score / len(results) if results else 0.0,
            )

            return final_answer

        except Exception as e:
            return f"❌ 智能问答失败: {str(e)}\n💡 请检查知识库状态或稍后重试"
