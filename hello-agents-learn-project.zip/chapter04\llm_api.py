import os
from dotenv import load_dotenv
from openai import OpenAI
from typing import Dict,List

# 加载环境变量
load_dotenv()

class HelloAgentsLLM:
    """
    一个简单的LLM客户端，封装了与OpenAI API的交互，提供一个统一的接口。
    它用于调用任何兼容OpenAI接口的服务，并默认使用流式响应式生成结果。
    """
    def __init__(self,model:str=None,api_key:str=None,base_url:str=None,timeout:int=None):
        """
        初始化客户端，优先使用传入的参数，如果没有则从环境变量中读取。
        """  
        self.model = model or os.getenv("LLM_MODEL_ID")
        self.api_key = api_key or os.getenv("LLM_API_KEY")
        self.base_url = base_url or os.getenv("LLM_BASE_URL")
        self.timeout = timeout or 30 #默认超时时间为30秒 

        if not all([self.model,self.api_key,self.base_url]):
            raise ValueError("请确保提供模型ID、API密钥和基础URL，或者在环境变量中设置它们。")
        self.client = OpenAI(api_key=self.api_key,base_url=self.base_url)
    
    def think(self,message:List[Dict[str,str]],temperature:float=0) -> str:
        """
        调用LLM API来生成回应。
        参数:
            message: List[Dict[str, str]], 包含系统提示和用户输入的消息列表。
            temperature: float, 控制生成文本的随机程度，值越高生成的文本越随机。
            """
        print("正在调用模型{}...".format(self.model))
        try:
            response = self.client.chat.completions.create(
                model = self.model,
                messages = message,
                temperature = temperature,
                stream = True, #默认使用流式响应
            )
            #处理流式响应，逐步构建完整的回答
            print("模型响应成功，正在处理流式输出...")
            collected_content = []
            for chunk in response:
                content =chunk.choices[0].delta.content or ""
                print(content,end="",flush=True) #实时输出生成的内容
                collected_content.append(content)
            print()#换行
            return "".join(collected_content)
        except Exception as e:
            print(f"调用LLM API时发生错误: {e}")
            return "错误：调用语言模型服务时出错。"

# --- 下面是一个使用示例 ---
if __name__ == "__main__":
    llm = HelloAgentsLLM()
    try:
        llmClient = HelloAgentsLLM()
        
        example_message = [
            {"role":"system","content":"you are a helpful assistant"},
            {"role":"user","content":"你好，请介绍你自己。"}
        
        ]
        print("-- 调用LLM生成回答 --")
        response = llmClient.think(example_message,temperature=0.7)
        if response:
            print("LLM的回答:")
            print(response)
    except Exception as e:
        print(f"发生错误: {e}")
