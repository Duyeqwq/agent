# my_main.py
import os
from dotenv import load_dotenv
from my_llm import MyLLM # 注意:这里导入我们自己的类

# 加载环境变量
load_dotenv()

provider = "auto"
model = "deepseek-chat"
llm = MyLLM(provider=provider, model=model)

# 准备消息
messages = [{"role": "user", "content": "你好，写一篇有关于春天的散文。"}]

# 发起调用，think等方法都已从父类继承，无需重写
response_stream = llm.think(messages)

# 打印响应
print("ModelScope Response:")
for chunk in response_stream:
    # chunk在my_llm库中已经打印过一遍，这里只需要pass即可
    # print(chunk, end="", flush=True)
    pass
