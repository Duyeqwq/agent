import os
from dotenv import load_dotenv

from hello_agents.tools import RAGTool

# Load .env from project root
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
load_dotenv(os.path.join(ROOT_DIR, ".env"), override=True)

# Use an isolated collection/namespace for this demo
collection_name = "followup_demo"
rag_namespace = "followup_demo"

rag_tool = RAGTool(
    knowledge_base_path="./knowledge_base",
    collection_name=collection_name,
    rag_namespace=rag_namespace,
)

# Clean the demo collection to keep results stable
rag_tool.execute("clear", confirm=True)

# Seed a small knowledge base about QMT
seed_docs = [
    (
        "qmt_opening",
        "QMT开通流程：需先在券商开户并完成风险评估，签署相关协议后，在交易终端里申请开通QMT权限。",
    ),
    (
        "qmt_fee",
        "QMT费率说明：具体佣金由券商决定，可能包含交易佣金与平台服务费，详情以开户券商公告为准。",
    ),
    (
        "qmt_limits",
        "QMT权限可能与账户类型、资金规模有关，不同券商的开通条件略有差异。",
    ),
    (
        "other_tool_fee",
        "某些量化平台的费率包含策略托管费与数据服务费，与券商交易佣金不同。",
    ),
]

for doc_id, text in seed_docs:
    result = rag_tool.execute("add_text", text=text, document_id=doc_id)
    print(f"初始化: {doc_id} -> {result}")

questions = [
    "QMT怎么开通？",
    "那它的费率是多少？",
    "开户需要什么资料？",
]

print("\n=== 直接检索（不补全上下文） ===")
for q in questions:
    print(f"\n用户问题: {q}")
    print(rag_tool.execute("search", query=q, limit=3, min_score=0.1))

print("\n=== 简单补全（将上轮主题拼回去） ===")
last_topic = None
for q in questions:
    if "QMT" in q:
        last_topic = "QMT"

    need_context = any(token in q for token in ["它", "那", "这个", "费率", "开户"])
    if last_topic and "QMT" not in q and need_context:
        search_query = f"{last_topic} {q}"
    else:
        search_query = q

    print(f"\n用户问题: {q}")
    print(f"检索Query: {search_query}")
    print(rag_tool.execute("search", query=search_query, limit=3, min_score=0.1))
