# my_llm.py
import os
from typing import Optional
from openai import OpenAI
from hello_agents import HelloAgentsLLM

class MyLLM(HelloAgentsLLM):
    """
    # 实例化客户端:
# ===== 切换指南 =====
# 1. 想用原来的 DeepSeek:
#    provider = "auto"
#    model = "deepseek-chat"
#
# 2. 想用 ModelScope (魔搭):
#    provider = "modelscope"
#    model = "MiniMax/MiniMax-M2.5" # 或 None 读环境变量
# ====================
    如:provider = "modelscope"
      model = None
      llm = MyLLM(provider=provider, model=model)
    """
    def __init__(
            self,
            model:Optional[str] = None,
            api_key:Optional[str] = None,
            base_url:Optional[str] = None,
            provider:Optional[str] = "auto",
            **kwargs
    ):
        provider = provider or os.getenv("LLM_PROVIDER") or "auto"

        #检查provider 是否为我们想处理的'modelscope'
        if provider  == "modelscope":
            print("正在使用自定义的 ModelScope Provider")
            self.provider = "modelscope"

            #解析 ModelScope 的凭证
            self.api_key = api_key or os.getenv("MODELSCOPE_API_KEY")
            self.base_url = base_url or "https://api-inference.modelscope.cn/v1/"

            #验证凭证是否存在
            if not self.api_key:
                raise ValueError("ModelScope API key not found. Please set MODELSCOPE_API_KEY environment variable.")
            
            #设置默认模型和其他参数
            scoped_model = os.getenv("MODELSCOPE_MODEL_ID")
            generic_model = os.getenv("LLM_MODEL_ID")
            selected_model = model or scoped_model

            # 兼容旧配置: 允许回退到 LLM_MODEL_ID，但拦截明显的 provider 串配置
            if not selected_model and generic_model and "deepseek" not in generic_model.lower():
                selected_model = generic_model

            self.model = selected_model or "Qwen/Qwen2.5-VL-72B-Instruct"
            self.temperature = kwargs.get('temperature', 0.7)
            self.max_tokens = kwargs.get('max_tokens')
            self.timeout = kwargs.get('timeout', 60)

            #使用获取的参数创建OpenAI客户端实例
            self._client = OpenAI(api_key=self.api_key, base_url=self.base_url, timeout=self.timeout)
        else:
            #如果不是 modelscope, 则完全使用父类的原始逻辑来处理
            super().__init__(model=model, api_key=api_key, base_url=base_url, provider=provider, **kwargs)
