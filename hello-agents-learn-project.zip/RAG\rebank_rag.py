from hello_agents import SimpleAgent, HelloAgentsLLM, ToolRegistry
from rag_tool_rerank import RerankRAGTool

import os
from dotenv import load_dotenv
load_dotenv(override=True)
# 创建具有RAG能力的Agent
llm = HelloAgentsLLM(
    llm = os.getenv("LLM_MODEL_ID") or "deepseek-chat",
    api_key = os.getenv("LLM_API_KEY"),
    base_url = os.getenv("LLM_BASE_URL"),
)
agent = SimpleAgent(name="知识助手", llm=llm)

# 创建RAG工具（使用本脚本自带的测试知识库）
rag_tool = RerankRAGTool(
    knowledge_base_path="./knowledge_base",
    collection_name="test_collection",
    rag_namespace="test"
)

# 本地 rerank 模型路径（优先读环境变量）
rerank_model_path = os.getenv("RERANK_MODEL_PATH")
default_local_reranker = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "models",
        "cross-encoder-ms-marco-MiniLM-L-6-v2",
    )
)
rerank_model_name = os.getenv("RERANK_MODEL_NAME") or "cross-encoder/ms-marco-MiniLM-L-6-v2"

if not rerank_model_path:
    rerank_model_path = default_local_reranker

rerank_model = rerank_model_path if os.path.exists(rerank_model_path) else rerank_model_name

tool_registry = ToolRegistry()
tool_registry.register_tool(rag_tool)
agent.tool_registry = tool_registry

# 体验RAG功能（增加干扰项，便于观察 rerank 效果）
documents = [
    (
        "python_intro",
        "Python is a high-level programming language created by Guido van Rossum and first released in 1991. Its design philosophy emphasizes readability and simplicity.",
    ),
    (
        "python_history",
        "Python development started in 1989 and the first public release was in 1991. Early versions focused on fast development and clear syntax.",
    ),
    (
        "monty_python",
        "The language name comes from the comedy group Monty Python, not the snake.",
    ),
    (
        "python_snake",
        "A python is a large constrictor snake found in tropical regions and is unrelated to the programming language.",
    ),
    (
        "java_history",
        "Java was released by Sun in 1995 and emphasized portability through the JVM ecosystem.",
    ),
    (
        "ml_basics",
        "Machine learning is a branch of AI that lets computers learn patterns from data. Major types include supervised, unsupervised, and reinforcement learning.",
    ),
    (
        "deep_learning",
        "Deep learning is a subfield of machine learning that uses multi-layer neural networks to learn complex features.",
    ),
    (
        "rag_concept",
        "RAG (retrieval-augmented generation) combines information retrieval with text generation to improve answer quality.",
    ),
    (
        "vector_db",
        "Vector databases are designed for similarity search; popular systems include Qdrant, FAISS, and Milvus.",
    ),
    (
        "transformer_intro",
        "The Transformer architecture uses multi-head attention and feed-forward networks and is a core building block for modern LLMs.",
    ),
]

for index, (doc_id, text) in enumerate(documents, 1):
    result = rag_tool.execute(
        "add_text",
        text=text,
        document_id=doc_id,
    )
    print(f"知识{index}: {result}")


query = "history of the Python programming language"

print("\n=== 搜索知识（不启用 rerank） ===")
result = rag_tool.execute(
    "search",
    query=query,
    limit=5,
    min_score=0.1,
    rerank=False,
)
print(result)

print("\n=== 搜索知识（启用 rerank） ===")
result = rag_tool.execute(
    "search",
    query=query,
    limit=5,
    min_score=0.1,
    rerank=True,
    rerank_model=rerank_model,
    candidate_pool_multiplier=8,
)
print(result)

print("\n=== 知识库统计 ===")
result = rag_tool.execute("stats")
print(result)
