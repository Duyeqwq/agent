
import os
from serpapi import SerpApiClient


def _format_results(results: dict) -> str | None:
    if "answer_box" in results and "answer" in results["answer_box"]:
        return results["answer_box"]["answer"]
    if "answer_box" in results and "snippet" in results["answer_box"]:
        return results["answer_box"]["snippet"]
    if "knowledge_graph" in results and "description" in results["knowledge_graph"]:
        return results["knowledge_graph"]["description"]
    if "organic_results" in results and results["organic_results"]:
        snippets = []
        for i, res in enumerate(results["organic_results"][:3]):
            title = res.get("title", "")
            snippet = res.get("snippet", "")
            if not snippet and isinstance(res.get("snippet_highlighted_words"), list):
                snippet = "；".join(res.get("snippet_highlighted_words", []))
            link = res.get("link", "")
            snippets.append(f"[{i+1}] {title}\n{snippet}\n{link}".strip())
        return "\n\n".join(snippets)
    if "related_questions" in results and results["related_questions"]:
        questions = [q.get("question", "") for q in results["related_questions"][:3]]
        return "相关问题:\n" + "\n".join([f"[{i+1}] {q}" for i, q in enumerate(questions)])
    if "top_stories" in results and results["top_stories"]:
        stories = []
        for i, s in enumerate(results["top_stories"][:3]):
            stories.append(f"[{i+1}] {s.get('title', '')}\n{s.get('link', '')}")
        return "\n\n".join(stories)
    return None

def search(query: str) -> str:
    """
    一个基于SerpApi的实战网页搜索引擎工具。
    它会智能地解析搜索结果，优先返回直接答案或知识图谱信息。
    """
    print(f"🔍 正在执行 [SerpApi] 网页搜索: {query}")
    try:
        api_key = os.getenv("SERPAPI_API_KEY")
        if not api_key:
            return "错误:SERPAPI_API_KEY 未在 .env 文件中配置。"

        attempts = [
            {"engine": "google", "gl": "cn", "hl": "zh-cn", "num": 10},
            {"engine": "google", "gl": "us", "hl": "en", "google_domain": "google.com", "num": 10},
            {"engine": "baidu", "ct": 2, "rn": 10},
        ]

        last_error = ""
        for strategy in attempts:
            params = {"q": query, "api_key": api_key, **strategy}
            results = SerpApiClient(params).get_dict()

            if "error" in results:
                error_msg = str(results.get("error", ""))
                last_error = error_msg
                # 该错误通常是某个引擎/区域无结果，继续尝试下一种策略。
                if "returned any results" in error_msg.lower():
                    continue
                return f"SerpAPI 返回错误: {error_msg}"

            formatted = _format_results(results)
            if formatted:
                return formatted

        if last_error:
            return f"SerpAPI 返回错误: {last_error}"
        return f"对不起，没有找到关于 '{query}' 的信息。"

    except Exception as e:
        return f"搜索时发生错误: {e}"
