import torch
import torch.nn as nn
import math

class PositionalEncoding(nn.Module):
    """
    位置编码模块
    """
    def __init__(self, d_model, max_len=5000):
        """
        初始化位置编码
        :param d_model: 词嵌入维度（必须与Transformer模型一致）
        :param max_len: 最大序列长度（默认5000）
        """
        super(PositionalEncoding, self).__init__()
        self.d_model = d_model

        # 创建位置编码矩阵（max_len × d_model）
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        
        # 偶数维度使用sin，奇数维度使用cos
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        # 添加batch维度（1 × max_len × d_model）
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)  # 注册为缓冲区（不参与梯度更新）

    def forward(self, x):
        """
        前向传播：将位置编码添加到输入嵌入
        :param x: 输入张量（batch_size × seq_length × d_model）
        :return: 添加位置编码后的张量
        """
        # 裁剪位置编码到输入序列长度，并缩放以匹配嵌入维度
        x = x + self.pe[:, :x.size(1), :]
        return x
 
class MultiHeadAttention(nn.Module):
    """
    多头注意力机制：将输入拆分为多个头，并行计算注意力，增强模型表达能力
    """
    def __init__(self, d_model, num_heads):
        """
        初始化多头注意力
        :param d_model: 词嵌入维度
        :param num_heads: 注意力头数量（必须能整除d_model）
        """
        super(MultiHeadAttention, self).__init__()
        assert d_model % num_heads == 0, "d_model 必须能被 num_heads 整除"
        
        self.d_model = d_model # 词嵌入维度（如512）
        self.num_heads = num_heads # 注意力头数量（如8）
        self.d_k = d_model // num_heads  # 每个头的维度

        # 定义Q、K、V的线性变换层（将输入映射到不同子空间）
        self.W_q = nn.Linear(d_model, d_model) # 查询（Query）的线性变换
        self.W_k = nn.Linear(d_model, d_model) # 键（Key）的线性变换
        self.W_v = nn.Linear(d_model, d_model) # 值（Value）的线性变换
        self.W_o = nn.Linear(d_model, d_model)  # 合并多头输出的线性层

    def scaled_dot_product_attention(self, Q, K, V, mask=None):
        """
        缩放点积注意力：计算注意力权重并加权求和
        :param Q: 查询矩阵（batch_size × num_heads × seq_length × d_k）
        :param K: 键矩阵（batch_size × num_heads × seq_length × d_k）
        :param V: 值矩阵（batch_size × num_heads × seq_length × d_k）
        :param mask: 掩码（可选，用于屏蔽未来信息）
        :return: 注意力输出（batch_size × num_heads × seq_length × d_k）
        """
        # 1. 计算注意力得分（QK^T / √d_k）
        attn_scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_k)
        
        # 2. 应用掩码（防止看到未来信息，如解码器中的“未来词”）
        if mask is not None:
            attn_scores = attn_scores.masked_fill(mask == 0, -1e9)  # 将mask为0的位置设为-∞，softmax后权重趋近0
        
        # 3. 计算注意力权重（Softmax）
        attn_probs = torch.softmax(attn_scores, dim=-1)
        
        # 4. 加权求和（权重 * V）
        output = torch.matmul(attn_probs, V)
        return output

    def split_heads(self, x):
        """
        拆分多头：将输入张量拆分为多个头
        :param x: 输入张量（batch_size × seq_length × d_model）
        :return: 拆分后的张量（batch_size × num_heads × seq_length × d_k）
        """
        batch_size, seq_length, d_model = x.size()
        return x.view(batch_size, seq_length, self.num_heads, self.d_k).transpose(1, 2)

    def combine_heads(self, x):
        """
        合并多头：将多个头的输出合并为原始维度
        :param x: 输入张量（batch_size × num_heads × seq_length × d_k）
        :return: 合并后的张量（batch_size × seq_length × d_model）
        """
        batch_size, num_heads, seq_length, d_k = x.size()
        return x.transpose(1, 2).contiguous().view(batch_size, seq_length, self.d_model)

    def forward(self, Q, K, V, mask=None):
        """
        前向传播：实现多头注意力
        :param Q: 查询（Query）
        :param K: 键（Key）
        :param V: 值（Value）
        :param mask: 掩码（可选）
        :return: 多头注意力输出（batch_size × seq_length × d_model）
        """
        # 1. 对Q、K、V进行线性变换并拆分多头
        Q = self.split_heads(self.W_q(Q))
        K = self.split_heads(self.W_k(K))
        V = self.split_heads(self.W_v(V))
        
        # 2. 计算缩放点积注意力
        attn_output = self.scaled_dot_product_attention(Q, K, V, mask)
        
        # 3. 合并多头输出并进行最终线性变换
        output = self.W_o(self.combine_heads(attn_output))
        return output

class PositionwiseFeedForward(nn.Module):
    """
    前馈神经网络模块
    如果说注意力层的作用是从整个序列中“动态地聚合”相关信息，那么前馈网络的作用从这些聚合
后的信息中提取更高阶的特征。
    """
    def __init__(self, d_model, d_ff):
        super(PositionwiseFeedForward, self).__init__()
        self.linear1 = nn.Linear(d_model, d_ff) # 第一个线性层，将维度从d_model提升到d_ff,一般来说dff会比d_model大很多，如2048，而d_model通常是512或768
        self.linear2 = nn.Linear(d_ff, d_model) # 第二个线性层，将维度从d_ff降回d_model
        self.dropout = nn.Dropout(0.1) # Dropout层，防止过拟合

    def forward(self,x):
        # x 形状: (batch_size, seq_length, d_model)
        x = self.linear1(x) # 线性变换
        x = torch.relu(x) # 激活函数
        x = self.dropout(x) # Dropout
        x = self.linear2(x) # 线性变换
        # 输出形状: (batch_size, seq_length, d_model)
        return x

#下面是核心层
      
class Encoderlayer(nn.Module):
    def __init__(self,d_model,num_heads,d_ff,dropout):
        super(Encoderlayer,self).__init__()
        self.self_attn = MultiHeadAttention()#待实现
        self.feed_forward = PositionwiseFeedForward()#待实现
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self,x,mask):
        #1.多头自注意力
        attn_output = self.self_attn(x,x,x,mask)
        x = self.norm1(x + self.dropout(attn_output))#残差连接和层归一化

        #2.前馈神经网络
        ff_output = self.feed_forward(x)
        x = self.norm2(x + self.dropout(ff_output))#残差连接和层归一化

        return x

# 解码器核心层

class DecoderLayer(nn.Module):
    def __init__(self,d_model,num_heads,d_ff,dropout):
        super(DecoderLayer,self).__init__()
        self.self_attn = MultiHeadAttention()#待实现
        self.cross_attn = MultiHeadAttention()#待实现
        self.feed_forward = PositionwiseFeedForward()#待实现
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self,x,encoder_ouput,src_mask,tgt_mask):
        # 掩码多头自注意力（对自己）
        attn_output = self.self_attn(x,x,x,tgt_mask)
        x = self.norm1(x + self.dropout(attn_output))#残差连接和层归一化

        # 交叉注意力（对编码器输出）
        cross_attn_output = self.cross_attn(x,encoder_ouput,encoder_ouput,src_mask)
        x = self.norm2(x + self.dropout(cross_attn_output))#残差连接和层归一化

        # 前馈神经网络
        ff_output = self.feed_forward(x)
        x = self.norm3(x + self.dropout(ff_output))#残差连接和层归一化

        return x
