"""
智能搜索助手 - 基于 LangGraph + Tavily API 的真实搜索系统
带 SigNoz Traces + Metrics (性能指标) 完整监控
"""

import asyncio
import time
import os
from typing import TypedDict, Annotated
from dotenv import load_dotenv

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import InMemorySaver
from tavily import TavilyClient

# ----------- 1. OpenTelemetry 追踪 (Traces) 与 指标 (Metrics) 配置 -----------
from opentelemetry import trace, metrics
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

# 新增 Metrics 相关导入
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter

load_dotenv()

# 定义服务资源属性
resource = Resource(attributes={"service.name": "my_search_assistant"})

# --- 配置 Traces ---
otlp_trace_exporter = OTLPSpanExporter(endpoint="http://localhost:4317")
tracer_provider = TracerProvider(resource=resource)
tracer_provider.add_span_processor(BatchSpanProcessor(otlp_trace_exporter))
trace.set_tracer_provider(tracer_provider)

# --- 配置 Metrics (新增) ---
otlp_metric_exporter = OTLPMetricExporter(endpoint="http://localhost:4317")
metric_reader = PeriodicExportingMetricReader(otlp_metric_exporter)
meter_provider = MeterProvider(resource=resource, metric_readers=[metric_reader])
metrics.set_meter_provider(meter_provider)

# 获取 Meter 并创建指标采集器
meter = metrics.get_meter("search_assistant_metrics")

llm_calls_counter = meter.create_counter(
    name="llm_calls_total",
    description="Total number of LLM API calls"
)
llm_tokens_counter = meter.create_counter(
    name="llm_tokens_total",
    description="Total number of tokens processed by LLM"
)
llm_latency_histogram = meter.create_histogram(
    name="llm_request_duration_seconds",
    description="Duration of LLM requests in seconds",
    unit="s"
)

# ----------- 2. 辅助函数：记录 LLM 性能指标 (新增) -----------
def record_llm_metrics(start_time: float, response, span, model_name: str):
    duration = time.time() - start_time
    attributes = {"llm.model": model_name}

    # 1. 记录基础指标
    llm_calls_counter.add(1, attributes)
    llm_latency_histogram.record(duration, attributes)

    # 2. 深度探测 DeepSeek 的 Token 存放位置
    # 路径 A: LangChain 0.2+ 的标准路径
    usage = getattr(response, "usage_metadata", {}) or {}
    
    # 路径 B: 如果 A 没拿到，看 response_metadata
    if not usage:
        usage = response.response_metadata.get("token_usage", {})
        
    # 路径 C: DeepSeek 有时会放在 additional_kwargs 里
    if not usage:
        usage = response.additional_kwargs.get("usage", {})

    # 提取具体数值 (适配不同 Key 名)
    p_tk = usage.get("prompt_tokens") or usage.get("input_tokens") or 0
    c_tk = usage.get("completion_tokens") or usage.get("output_tokens") or 0
    total = usage.get("total_tokens") or (p_tk + c_tk)

    # --- 强力调试打印 ---
    print(f"\n🔍 [METRICS CHECK] Model: {model_name} | Tokens: {total} | Latency: {duration:.2f}s")
    if total == 0:
        print(f"⚠️ 警告: 未检测到 Token！Metadata 内容如下: {response.response_metadata}")
    # ------------------

    if total > 0:
        llm_tokens_counter.add(total, attributes)
        # 写入 Trace 方便在 SigNoz Traces 视图查看
        span.set_attribute("llm.usage.total_tokens", total)
        span.set_attribute("llm.usage.prompt_tokens", p_tk)
        span.set_attribute("llm.usage.completion_tokens", c_tk)
    
    span.set_attribute("llm.latency", duration)
# ----------- 3. 业务逻辑初始化 -----------
class SearchState(TypedDict):
    messages: Annotated[list, add_messages]
    user_query: str
    search_query: str
    search_results: str
    final_answer: str
    step: str

MODEL_ID = os.getenv("LLM_MODEL_ID", "gpt-4o-mini")
llm = ChatOpenAI(
    model=MODEL_ID,
    api_key=os.getenv("LLM_API_KEY"),
    base_url=os.getenv("LLM_BASE_URL", "https://api.openai.com/v1"),
    temperature=0.7,
    
)

tavily_client = TavilyClient(api_key=os.getenv("TAVILY_API_KEY"))

# ----------- 4. 节点定义 -----------
def understand_query_node(state: SearchState) -> SearchState:
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("understand_query_node") as span:
        user_message = next((msg.content for msg in reversed(state["messages"]) if isinstance(msg, HumanMessage)), "")
        
        understand_prompt = f"""分析用户的查询："{user_message}"
请完成两个任务：
1. 简洁总结用户想要了解什么
2. 生成最适合搜索的关键词（中英文均可，要精准）
格式：
理解：[用户需求总结]
搜索词：[最佳搜索关键词]"""

        # 记录调用前的时间
        start_time = time.time()
        response = llm.invoke([SystemMessage(content=understand_prompt)])
        # 提取指标并发送
        record_llm_metrics(start_time, response, span, MODEL_ID)
        
        response_text = response.content
        search_query = user_message
        if "搜索词：" in response_text:
            search_query = response_text.split("搜索词：")[1].strip()
        elif "搜索关键词：" in response_text:
            search_query = response_text.split("搜索关键词：")[1].strip()
        
        span.set_attribute("user_query", user_message)
        span.set_attribute("search_query", search_query)
        
        return {
            "user_query": response.content,
            "search_query": search_query,
            "step": "understood",
            "messages": [AIMessage(content=f"我理解您的需求：{response.content}")]
        }

def tavily_search_node(state: SearchState) -> SearchState:
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("tavily_search_node") as span:
        search_query = state["search_query"]
        try:
            print(f"🔍 正在搜索: {search_query}")
            response = tavily_client.search(
                query=search_query, search_depth="basic", include_answer=True, include_raw_content=False, max_results=5
            )
            
            search_results = f"综合答案：\n{response['answer']}\n\n" if response.get("answer") else ""
            if response.get("results"):
                search_results += "相关信息：\n"
                for i, result in enumerate(response["results"][:3], 1):
                    search_results += f"{i}. {result.get('title', '')}\n{result.get('content', '')}\n来源：{result.get('url', '')}\n\n"
            
            if not search_results:
                search_results = "抱歉，没有找到相关信息。"
            
            span.set_attribute("search_query", search_query)
            span.set_attribute("search_results_count", len(response.get("results", [])))
            
            return {
                "search_results": search_results,
                "step": "searched",
                "messages": [AIMessage(content=f"✅ 搜索完成！找到了相关信息，正在为您整理答案...")]
            }
        except Exception as e:
            error_msg = f"搜索时发生错误: {str(e)}"
            print(f"❌ {error_msg}")
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
            return {
                "search_results": f"搜索失败：{error_msg}",
                "step": "search_failed",
                "messages": [AIMessage(content="❌ 搜索遇到问题，我将基于已有知识为您回答")]
            }

def generate_answer_node(state: SearchState) -> SearchState:
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("generate_answer_node") as span:
        if state["step"] == "search_failed":
            prompt = f"搜索API暂时不可用，请基于您的知识回答用户的问题：\n\n用户问题：{state['user_query']}\n\n请提供一个有用的回答，并说明这是基于已有知识的回答。"
            span.set_attribute("fallback_used", True)
        else:
            prompt = f"基于以下搜索结果为用户提供完整、准确的答案：\n\n用户问题：{state['user_query']}\n\n搜索结果：\n{state['search_results']}\n\n请要求：\n1. 综合搜索结果，提供准确回答\n2. 引用来源\n3. 结构清晰"
            span.set_attribute("search_results_used", True)

        # 记录调用前的时间
        start_time = time.time()
        response = llm.invoke([SystemMessage(content=prompt)])
        # 提取指标并发送
        record_llm_metrics(start_time, response, span, MODEL_ID)
        
        return {
            "final_answer": response.content,
            "step": "completed",
            "messages": [AIMessage(content=response.content)]
        }

# ----------- 5. 编排与主循环 -----------
def create_search_assistant():
    workflow = StateGraph(SearchState)
    workflow.add_node("understand", understand_query_node)
    workflow.add_node("search", tavily_search_node)
    workflow.add_node("answer", generate_answer_node)
    
    workflow.add_edge(START, "understand")
    workflow.add_edge("understand", "search")
    workflow.add_edge("search", "answer")
    workflow.add_edge("answer", END)
    
    return workflow.compile(checkpointer=InMemorySaver())

async def main():
    if not os.getenv("TAVILY_API_KEY"):
        print("❌ 错误：请在.env文件中配置TAVILY_API_KEY")
        return
    
    app = create_search_assistant()
    print("🔍 智能搜索助手启动！(带有 OTel Metrics 监控)")
    print("(输入 'quit' 退出)\n")
    
    session_count = 0
    while True:
        user_input = input("🤔 您想了解什么: ").strip()
        if user_input.lower() in ['quit', 'q', '退出', 'exit']:
            break
        if not user_input: continue
        
        session_count += 1
        config = {"configurable": {"thread_id": f"search-session-{session_count}"}}
        initial_state = {
            "messages": [HumanMessage(content=user_input)], "user_query": "",
            "search_query": "", "search_results": "", "final_answer": "", "step": "start"
        }
        
        try:
            print("\n" + "="*60)
            async for output in app.astream(initial_state, config=config):
                for node_name, node_output in output.items():
                    if "messages" in node_output and node_output["messages"]:
                        latest = node_output["messages"][-1]
                        if isinstance(latest, AIMessage):
                            if node_name == "understand": print(f"🧠 理解阶段: {latest.content}")
                            elif node_name == "search": print(f"🔍 搜索阶段: {latest.content}")
                            elif node_name == "answer": print(f"\n💡 最终回答:\n{latest.content}")
            print("\n" + "="*60 + "\n")
        except Exception as e:
            print(f"❌ 发生错误: {e}")

if __name__ == "__main__":
    asyncio.run(main())