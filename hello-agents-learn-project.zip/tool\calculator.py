"""基础计算工具。"""

import ast


_ALLOWED_BINARY_OPS = {
	ast.Add: lambda a, b: a + b,
	ast.Sub: lambda a, b: a - b,
	ast.Mult: lambda a, b: a * b,
	ast.Div: lambda a, b: a / b,
	ast.Mod: lambda a, b: a % b,
	ast.Pow: lambda a, b: a**b,
}

_ALLOWED_UNARY_OPS = {
	ast.UAdd: lambda a: +a,
	ast.USub: lambda a: -a,
}


def _normalize_expression(expression: str) -> str:
	"""将常见符号转换为 Python 可解析格式。"""
	return (
		expression.replace("（", "(")
		.replace("）", ")")
		.replace("×", "*")
		.replace("x", "*")
		.replace("X", "*")
		.replace("÷", "/")
		.replace("^", "**")
		.strip()
	)


def _eval_ast(node: ast.AST) -> float:
	if isinstance(node, ast.Expression):
		return _eval_ast(node.body)

	if isinstance(node, ast.Constant):
		if isinstance(node.value, (int, float)):
			return float(node.value)
		raise ValueError("仅支持数字常量")

	ast_num = getattr(ast, "Num", None)
	if ast_num is not None and isinstance(node, ast_num):
		return float(node.n)

	if isinstance(node, ast.BinOp):
		op = type(node.op)
		if op not in _ALLOWED_BINARY_OPS:
			raise ValueError("包含不支持的运算符")
		left = _eval_ast(node.left)
		right = _eval_ast(node.right)
		return _ALLOWED_BINARY_OPS[op](left, right)

	if isinstance(node, ast.UnaryOp):
		op = type(node.op)
		if op not in _ALLOWED_UNARY_OPS:
			raise ValueError("包含不支持的一元运算")
		value = _eval_ast(node.operand)
		return _ALLOWED_UNARY_OPS[op](value)

	raise ValueError("表达式包含不支持的语法")


def calculate(expression: str) -> str:
	"""计算数学表达式并返回字符串结果。"""
	print(f"[calculator] 正在计算: {expression}")
	if not expression or not expression.strip():
		return "错误: 请输入要计算的表达式。"

	try:
		normalized = _normalize_expression(expression)
		tree = ast.parse(normalized, mode="eval")
		result = _eval_ast(tree)

		if result.is_integer():
			return str(int(result))
		return str(result)

	except ZeroDivisionError:
		return "错误: 除数不能为 0。"
	except SyntaxError:
		return "错误: 表达式语法不正确。"
	except Exception as exc:
		return f"错误: 无法计算该表达式 ({exc})。"


if __name__ == "__main__":
	examples = ["1 + 2 * 3", "(10-3) / 2", "2^8", "9 % 4", "10 ÷ 2"]
	for exp in examples:
		print(f"{exp} = {calculate(exp)}")
